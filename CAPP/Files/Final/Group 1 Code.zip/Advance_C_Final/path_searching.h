#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define INFINITY 9999
#define MAX 40

int * dijkstra(int G[MAX][MAX],int n,int startnode, int endnode);

int search_name2num(char * x){
    int value;
    if(strncmp(x, "R14", 5)==0 || strncmp(x, "R15", 5)==0 || strncmp(x, "R16", 5)==0 || strncmp(x, "R17", 5)==0 || strncmp(x, "R18", 5)==0 || strncmp(x, "R19", 5)==0 || strncmp(x, "R20", 5)==0
    || strncmp(x, "R21", 5)==0 || strncmp(x, "R22", 5)==0 || strncmp(x, "R23", 5)==0 || strncmp(x, "R24", 5)==0 || strncmp(x, "R25", 5)==0 || strncmp(x, "R26", 5)==0 || strncmp(x, "R27", 5)==0
    || strncmp(x, "R28", 5)==0){
        value = 1;
    }
    else if(strncmp(x, "O50", 5)==0 || strncmp(x, "O51", 5)==0 ||strncmp(x, "O52", 5)==0 || strncmp(x, "O53", 5)==0 || strncmp(x, "O54", 5)==0){
        value = 2;
    }
    else if(strncmp(x, "Y19", 5)==0 || strncmp(x, "Y20", 5)==0){
        value = 3;
    }
    else if(strncmp(x, "O18", 5)==0 || strncmp(x, "O19", 5)==0  || strncmp(x, "O20", 5)==0 || strncmp(x, "O21", 5)==0){
        value = 4;
    }
    else if(strncmp(x, "O13", 5)==0 || strncmp(x, "O14", 5)==0  || strncmp(x, "O15", 5)==0 || strncmp(x, "O16", 5)==0){
        value = 5;
    }
    else if(strncmp(x, "O17", 5)==0 || strncmp(x, "Y18", 5)==0){
        value = 6;
    }
    else if(strncmp(x, "BL09", 5)==0 || strncmp(x, "BL10", 5)==0){
        value = 7;
    }
    else if(strncmp(x, "Y12", 5)==0 || strncmp(x, "Y13", 5)==0 || strncmp(x, "Y14", 5)==0 || strncmp(x, "Y15", 5)==0 || strncmp(x, "Y16", 5)==0
     || strncmp(x, "Y17", 5)==0 || strncmp(x, "BL07", 5)==0 || strncmp(x, "BL08", 5)==0){
        value = 8;
    }
    else if(strncmp(x, "BL01", 5)==0 || strncmp(x, "BL02", 5)==0 || strncmp(x, "BL03", 5)==0 || strncmp(x, "BL04", 5)==0 || strncmp(x, "BL05", 5)==0 || strncmp(x, "BL06", 5)==0){
        value = 9;
    }
    else if(strncmp(x, "BR12", 5)==0 || strncmp(x, "BR13", 5)==0 || strncmp(x, "BR14", 5)==0 || strncmp(x, "BR15", 5)==0 || strncmp(x, "BR16", 5)==0 || strncmp(x, "BR17", 5)==0
     || strncmp(x, "BR18", 5)==0 || strncmp(x, "BR19", 5)==0 || strncmp(x, "BR20", 5)==0 || strncmp(x, "BR21", 5)==0 || strncmp(x, "BR22", 5)==0 || strncmp(x, "BR23", 5)==0){
        value = 10;
    }
    else if(strncmp(x, "BL23", 5)==0 || strncmp(x, "BR24", 5)==0){
        value = 0;
    }
    else if(strncmp(x, "O12", 5)==0){
        value = 11;
    }
    else if(strncmp(x, "O11", 5)==0 || strncmp(x, "R13", 5)==0){
        value = 12;
    }
    else if(strncmp(x, "O09", 5)==0 || strncmp(x, "O10", 5)==0){
        value = 13;
    }
    else if(strncmp(x, "G13", 5)==0){
        value = 14;
    }
    else if(strncmp(x, "G14", 5)==0 || strncmp(x, "R11", 5)==0){
        value = 15;
    }
    else if(strncmp(x, "G15", 5)==0 || strncmp(x, "O08", 5)==0){
        value = 16;
    }
    else if(strncmp(x, "G16", 5)==0 || strncmp(x, "BR11", 5)==0){
        value = 17;
    }
    else if(strncmp(x, "BL11", 5)==0 || strncmp(x, "G12", 5)==0){
        value = 18;
    }
    else if(strncmp(x, "BL12", 5)==0 || strncmp(x, "R10", 5)==0){
        value = 19;
    }
    else if(strncmp(x, "BL14", 5)==0 || strncmp(x, "O11", 5)==0){
        value = 20;
    }
    else if(strncmp(x, "BL15", 5)==0 || strncmp(x, "BR10", 5)==0){
        value = 21;
    }
    else if(strncmp(x, "G11", 5)==0){
        value = 22;
    }
    else if(strncmp(x, "BL12", 5)==0 || strncmp(x, "R10", 5)==0){
        value = 23;
    }
    else if(strncmp(x, "R07", 5)==0 || strncmp(x, "O06", 5)==0){
        value = 24;
    }
    else if(strncmp(x, "R06", 5)==0){
        value = 25;
    }
    else if(strncmp(x, "R05", 5)==0 || strncmp(x, "BR09", 5)==0){
        value = 26;
    }
    else if(strncmp(x, "G09", 5)==0 || strncmp(x, "R07", 5)==0){
        value = 27;
    }
    else if(strncmp(x, "O03", 5)==0 || strncmp(x, "O04", 5)==0){
        value = 28;
    }
    else if(strncmp(x, "G05", 5)==0 || strncmp(x, "G06", 5)==0 || strncmp(x, "G07", 5)==0 || strncmp(x, "G08", 5)==0){
        value = 29;
    }
    else if(strncmp(x, "Y11", 5)==0 || strncmp(x, "O02", 5)==0){
        value = 30;
    }
    else if(strncmp(x, "Y08", 5)==0 || strncmp(x, "Y09", 5)==0 || strncmp(x, "Y10", 5)==0){
        value = 31;
    }
    else if(strncmp(x, "Y07", 5)==0 || strncmp(x, "G04", 5)==0){
        value = 32;
    }
    else if(strncmp(x, "G01", 5)==0 || strncmp(x, "G02", 5)==0 || strncmp(x, "G03", 5)==0){
        value = 33;
    }
    else if(strncmp(x, "G17", 5)==0 || strncmp(x, "G18", 5)==0 || strncmp(x, "G19", 5)==0){
        value = 34;
    }
    else if(strncmp(x, "BL16", 5)==0 || strncmp(x, "BL17", 5)==0  || strncmp(x, "BL18", 5)==0 || strncmp(x, "BL19", 5)==0 || strncmp(x, "BL20", 5)==0 || strncmp(x, "BL21", 5)==0 || strncmp(x, "BL22", 5)==0){
        value = 35;
    }
    else if(strncmp(x, "R02", 5)==0 || strncmp(x, "R03", 5)==0 || strncmp(x, "R04", 5)==0){
        value = 36;
    }
    else if(strncmp(x, "BR01", 5)==0 || strncmp(x, "BR02", 5)==0  || strncmp(x, "BR03", 5)==0 || strncmp(x, "BR04", 5)==0 || strncmp(x, "BR05", 5)==0 || strncmp(x, "BR06", 5)==0 || strncmp(x, "BR07", 5)==0 || strncmp(x, "BR08", 5)==0){
        value = 37;
    }
    else if(strncmp(x, "BL13", 5)==0){
        value = 38;
    }
    else if(strncmp(x, "O01", 5)==0){
        value = 39;
    }
    return value;
}

char * search_num2name(int x){
    static char y[5];
    switch(x){
        case 6:
            strcpy(y, "O17");
            break;
        case 8:
            strcpy(y, "BL08");
            break;
        case 11:
            strcpy(y, "O12");
            break;
        case 12:
            strcpy(y, "R13");
            break;
        case 15:
            strcpy(y, "R11");
            break;
        case 16:
            strcpy(y, "G15");
            break;
        case 17:
            strcpy(y, "G16");
            break;
        case 18:
            strcpy(y, "G12");
            break;
        case 19:
            strcpy(y, "R10");
            break;
        case 20:
            strcpy(y, "O07");
            break;
        case 21:
            strcpy(y, "BL15");
            break;
        case 23:
            strcpy(y, "R08");
            break;
        case 24:
            strcpy(y, "R07");
            break;
        case 26:
            strcpy(y, "R05");
            break;
        case 27:
            strcpy(y, "G09");
            break;
        case 30:
            strcpy(y, "Y11");
            break;
        case 32:
            strcpy(y, "G04");
            break;

    }
    return y;
}
 
void path(char x[5],char y[5])
{
    int i,j,start, end, *path;

    int G[MAX][MAX] = {{0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0},
                {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1},
                {0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0}};

    

    start = search_name2num(y);
    end = search_name2num(x);

    path = dijkstra(G, 40, start, end);

    //print the path and distance of each node
            
    j = end;
    printf("%s", x);
    while(j != start){
        j = path[j];
        if(j == start) break;
        printf(" -> %s", search_num2name(j));
    }
    printf(" -> %s", y);
  
}


 
int * dijkstra(int G[MAX][MAX],int n,int startnode, int endnode){
 
    int cost[MAX][MAX], distance[MAX];
    static int pred[MAX];
    int visited[MAX], count,mindistance, nextnode,i,j;
    
    //pred[] stores the predecessor of each node
    //count gives the number of nodes seen so far
    //create the cost matrix
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            if(G[i][j] == 0)
                cost[i][j] = INFINITY;
            else
                cost[i][j] = G[i][j];
    
    //initialize pred[],distance[] and visited[]
    for(i=0;i<n;i++){
        distance[i] = cost[startnode][i];
        pred[i] = startnode;
        visited[i] = 0;
    }
    
    distance[startnode] = 0;
    visited[startnode] = 1;
    count = 1;
    
    while(count < n-1){
        mindistance = INFINITY;
        
        //nextnode gives the node at minimum distance
        for(i=0;i<n;i++)
            if(distance[i]<mindistance && !visited[i]){
                mindistance = distance[i];
                nextnode=i;
            }
           
            //check if a better path exists through nextnode            
            visited[nextnode] = 1;
            for(i=0; i<n; i++)
                if(!visited[i])
                    if(mindistance + cost[nextnode][i] < distance[i]){
                        distance[i] = mindistance + cost[nextnode][i];
                        pred[i] = nextnode;
                    }
        count++;
    }

    return pred;

}
