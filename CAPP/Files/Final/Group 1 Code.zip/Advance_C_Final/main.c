#include <stdio.h>
#include "DurationAndPrice_searching.h"
#include "path_searching.h"

int main(){
	char start[100], end[100];
	int identity, price = 0, time = 0;
	
	printf("-------------------------------------------\n");
	printf("--   Welcome to the MRT Enquiry System   --\n");
	printf("-------------------------------------------\n\n");

	printAlias();
	printf("-------------------------------------------\n");
	//enter outset
	printf("- Please enter a starting point : ");
	scanf("%s", &start);
	printf("-------------------------------------------\n");

	//enter destination
	printf("- Please enter the destination : ");
	scanf("%s", &end);
	printf("-------------------------------------------\n");
	
	//enter identity
	printf("- Please enter your identity(Adult(0) - Elder(1) - Child(2)) : ");
	scanf("%d", &identity);
	printf("-------------------------------------------\n\n\n");


	price = durationAndPrice(start, end, identity);
	time = (int)returnDuration;

	printf("-------------------------------------------\n");
	printf("Price : %d\n", price);
	printf("Travel time : %s\n", duration);
	printf("Bus route : ");
	path(start,end);
	//print Bus route

	system ("pause");
	return 0;
} 
