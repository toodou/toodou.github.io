#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
void pres_enter(){
	fflush(stdin);
	char stop;
	Sleep(500);
	printf("\n");
	while (stop!='\n'){
	printf("���UEnter�~��");
	stop=getchar();
	}	
}
unsigned int dice(){
	unsigned int x=0;
	srand(time(NULL));
	x=(rand()%6)+1;
	return x;
}
void clean(){
	fflush(stdin);
}
int useitem(int master[]){
	system("cls");
	int a;
	while(1){
		printf("�ޯ�ż�:%d/%d  ��O��:%d/%d   �B���I��:%d/%d  \n\n",master[0],master[32],master[1],master[33],master[2],master[34]);
		printf("�n�ϥΪk�N�^�_��?\n\n�ޯ�żƦ^�_�N:%d  ��J1\n\n��O�Ȧ^�_�N:%d  ��J2\n\n�B���I�Ʀ^�_�N:%d  ��J3\n\n���}  ��J0\n\n",master[12],master[13],master[11]);
		scanf("%d",&a);
     	if(a==0){
    	break;
    	}
    	else if(a==1){/*�ޯ�żƦ^�_*/
			if(master[12]>0){
			if(master[0]<=master[32]){
				master[0]+=master[32]/2;
			if(master[0]>master[32]){
				master[0]=master[32];
			
			}
		}
		master[12]--;
		}
		else{
			printf("\n�A�S���������k�N\n\n");
		pres_enter();
		system("cls");
		}
		}
		else if(a==2){/*��O�Ȧ^�_�^�_*/
		if(master[13]>0){
			if(master[1]<=master[33]){
				master[1]+=master[33]/2;
			if(master[1]>master[33]){
				master[1]=master[33];
			}
		}
		master[13]--;
		}
		else{
		printf("\n�A�S���������k�N\n\n");
		pres_enter();
		system("cls");
		}
		
		}
		else if(a==3){/*�B���I�Ʀ^�_�^�_*/
		if(master[11]>0){
			if(master[2]<=master[34]){
				master[2]+=master[34]/2;
			if(master[2]>master[34]){
				master[2]=master[34];
			}
		}
		master[11]--;
		}
		else{
		
		printf("\n�A�S���������k�N\n\n");
		pres_enter();
		system("cls");
}
	}
		system("cls");
		clean();

		
		}
		system("cls");
	
	}

int fate_f(int master[]){
	int y,x=0;
	printf("�ոդ��\n\n");
	printf("���e�B���I��%d\n\n",master[2]);
	pres_enter();
	system("cls");
	printf("�ոդ��\n\n");
	Sleep(1000);
	x=dice();  
	printf("�Ĥ@���Y�X�F: %d     ",x);
	Sleep(1000); 
	y=dice();
	x+=y;
    printf("�ĤG���Y�X�F: %d\n\n",y);
	Sleep(1000);	
	if(x<=master[2]){				 //�`�M�p��B���I��
		printf("�n�B!!\n\n");
		master[2]--;
		printf("�Ѿl�B���I��: %d\n\n",master[2]);
		pres_enter();
	    system("cls");
		return 1;
	}
	else if(x>master[2]){			//�`�M�j��B���I��
		printf("����!!\n\n");	
		master[2]--;
		printf("�Ѿl�B���I��: %d\n\n",master[2]);
		pres_enter();
	    system("cls");
		return 0;
	} 
}

int fight1_1(int master[],int enemy[]){//�D���ĤH�Ѽ� 
	int i=0;//��� 
	int check,fate;//�T�{�B���I��//�B��ѼƦ^�� 
	int yx,yy;//�Y��Ѽ� 
	int ex,ey;//�Y��Ѽ� 
	int ya,ea;//�^�X�����O 
	while(1){
		++i;
		printf("��%d��\n\n",i);
		printf("�A���ޯ�ż�:%d  ��誺�ޯ�ż�:%d\n\n",master[0],enemy[0]);//
		printf("�A����O��:%d   ��誺��O��:%d\n",master[1],enemy[1]);//
		pres_enter();
	    system("cls");
		printf("��%d��\n\n",i);
		Sleep(1000);
		ex=dice();								//���Ĥ@���Y�� 
		printf("���Ĥ@���Y�X�F: %d     ",ex); 
		Sleep(1000);	
		ey=dice();								//���ĤG���Y�� 
		ex+=ey;									
		printf("���ĤG���Y�X�F: %d     ",ey);
		 
		ea=ex+enemy[0];							//���o�^�X�����O
		Sleep(1000);
		printf("���o�^�X�����O: %d\n\n",ea); 
		Sleep(1500);
		
		yx=dice();								//�A�Ĥ@���Y��
		printf("�A�Ĥ@���Y�X�F: %d      ",yx);
		Sleep(1000);
		yy=dice();							    //�A��ĤG���Y��
		yx+=yy;								   
		printf("�A�ĤG���Y�X�F: %d      ",yy);
		
		ya=yx+master[0];					  //�A�o�^�X�����O
		Sleep(1000);
		printf("�A�o�^�X�����O: %d\n\n",ya);
		pres_enter();
		system("cls");
		
		if(ya>ea){							//�A�������O�j���� 
		while(1){
			printf("�A����y���F���I�ˮ`�A�n�ϥιB���I�ƶ�?(�n��J1 ���n��J0) :");
			scanf("%d",&check);
			system("cls");
			if(check==1){		 			//�ϥιB���I��
				fate=fate_f(master);		//�B���˩w 
				if(fate==1){
				printf("�A����y���F�|�I�ˮ`\n");
				enemy[1]-=4;				//���\�A����y���F�|�I�ˮ`
				pres_enter();
	            system("cls");
				break;	
				}
				else if(fate==0){
				printf("�A����y���F�@�I�ˮ`\n");
				enemy[1]-=1;				//���ѡA ����y���F�@�I�ˮ`
				pres_enter();
	            system("cls");
				break;	
				}
			}
			else if(check==0){				//���ϥιB���I��
				printf("�A����y���F���I�ˮ`\n");
				enemy[1]-=2;				//����y���F���I�ˮ`
				pres_enter();
	            system("cls");
				break;
			}
		}	
		
			
		}
		else if(ya<ea){						//�A�������O�p���� 
		while(1){
			printf("����A�y���F���I�ˮ`�A�n�ϥιB���I�ƶ�?(�n��J1 ���n��J0) :");
			scanf("%d",&check);
			system("cls");
			if(check==1){					////�ϥιB���I��
				fate=fate_f(master);		//�B���˩w 
				if(fate==0){				
				printf("����A�y���F�|�I�ˮ`\n");
				master[1]-=4;				//���ѡA��A�y���F�|�I�ˮ`
				pres_enter();
	            system("cls");
				break;	
				}
				else if(fate==1){			
				printf("����A�y���F�@�I�ˮ`\n");
				master[1]-=1;				//���\�A��A�y���F�@�I�ˮ`
				pres_enter();
	            system("cls");
				break;	
				}
			}
			else if(check==0){				//���ϥιB���I��
				printf("����A�y���F���I�ˮ`\n");
				master[1]-=2;				//��A�y���F���I�ˮ`
				pres_enter();
	            system("cls");
				break;
			}
		}	
		}
		else{
		printf("�o������\n\n");
		pres_enter();
	    system("cls");	
		}
		if(enemy[1]<=0){					//�Ĥ覺�`
			system("cls");
			printf("�Ĥ覺�`");
			pres_enter();
	        system("cls");
			return 1;
		}
		else if(master[1]<=0){				//�A���`
			system("cls");
			return 0;
		}
	}
}


int main() {
	int master[35]={0};
	int i;
	printf("�w��Ө�԰��۷Q\n");
	pres_enter();
	system("cls");
	create(master,&i);
	while(1){
	if(i==0){
		printf("Bad End\n\n");
		break;
	}	
	else if(i==1){
	    page_1(master,&i);	
	}
	else if(i==2){
	    page_2(master,&i);		
	}
	else if(i==3){
	    page_3(master,&i);		
	}
	else if(i==4){
		page_4(master,&i);	
	}
	else if(i==5){
		page_5(master,&i);	
	}
	else if(i==6){
		page_6(master,&i);	
	}
	else if(i==7){
		page_7(master,&i);	
	}
	else if(i==8){
		page_8(master,&i);	
	}
	else if(i==9){
		page_9(master,&i);	
	}
	else if(i==10){
		page_10(master,&i);	
	}
	else if(i==11){
		page_11(master,&i);	
	}
	else if(i==12){
		page_12(master,&i);	
	}
	else if(i==13){
		page_13(master,&i);	
	}
	else if(i==14){
	 	page_14(master,&i);	
	}
	else if(i==15){
		page_15(master,&i);	
	}
	else if(i==16){
		page_16(master,&i);	
	}
	else if(i==17){
		page_17(master,&i);	
	}
	else if(i==18){
		page_18(master,&i);	
	}
	else if(i==19){
		page_19(master,&i);	
	}
	else if(i==20){
		page_20(master,&i);	
	}
	else if(i==21){
		page_21(master,&i);	
	}
	else if(i==22){
		page_22(master,&i);	
	}
	else if(i==23){
		page_23(master,&i);	
	}
	else if(i==24){
		page_24(master,&i);	
	}
	else if(i==25){
		page_25(master,&i);	
	}
	else if(i==26){
		page_26(master,&i);	
	}
	else if(i==27){
		page_27(master,&i);	
	}
	else if(i==28){
		page_28(master,&i);	
	}
	else if(i==29){
		page_29(master,&i);	
	}
	else if(i==30){
		page_30(master,&i);	
	}
	else if(i==31){
		page_31(master,&i);	
	}
	else if(i==32){
		page_32(master,&i);	
	}
	else if(i==33){
		page_33(master,&i);	
	}
	else if(i==34){
		page_34(master,&i);	
	}
	else if(i==35){
		page_35(master,&i);	
	}
	else if(i==36){
		page_36(master,&i);	
	}
	else if(i==37){
		page_37(master,&i);	
	}
	else if(i==38){
		page_38(master,&i);	
	}
	else if(i==39){
		page_39(master,&i);	
	}
	else if(i==40){
		page_40(master,&i);	
	}
	else if(i==41){
		page_41(master,&i);	
	}
	else if(i==42){
		page_42(master,&i);	
	}
	else if(i==43){
		page_43(master,&i);	
	}
	else if(i==44){
		page_44(master,&i);	
	}
	else if(i==45){
		page_45(master,&i);	
	}
	else if(i==46){
		page_46(master,&i);	
	}
	else if(i==47){
		page_47(master,&i);	
	}
	else if(i==48){
		page_48(master,&i);	
	}
	else if(i==49){
		page_49(master,&i);	
	}
	else if(i==50){
		page_50(master,&i);	
	}
	else if(i==51){
		page_51(master,&i);	
	}
	else if(i==52){
		page_52(master,&i);	
	}
	else if(i==53){
		page_53(master,&i);	
	}
	else if(i==54){
		page_54(master,&i);	
	}
	else if(i==55){
		page_55(master,&i);	
	}
	else if(i==56){
		page_56(master,&i);	
	}
	else if(i==57){
		page_57(master,&i);	
	}
	else if(i==58){
		page_58(master,&i);	
	}
	else if(i==59){
		page_59(master,&i);	
	}
	else if(i==60){
		page_60(master,&i);	
	}
	else if(i==61){
		page_61(master,&i);	
	}
	else if(i==62){
		page_62(master,&i);	
	}
	else if(i==63){
		page_63(master,&i);	
	}
	else if(i==64){
		page_64(master,&i);	
	}
	else if(i==65){
		page_65(master,&i);	
	}
	else if(i==66){
		page_66(master,&i);	
	}
	else if(i==67){
		page_67(master,&i);	
	}
	else if(i==68){
		page_68(master,&i);	
	}
	else if(i==69){
		page_69(master,&i);	
	}
	else if(i==70){
		page_70(master,&i);	
	}
	else if(i==71){
		page_71(master,&i);	
	}
	else if(i==72){
		page_72(master,&i);	
	}
	else if(i==73){
		page_73(master,&i);	
	}
	else if(i==74){
		page_74(master,&i);	
	}
	else if(i==75){
		page_75(master,&i);	
	}
	else if(i==76){
		page_76(master,&i);	
	}
	else if(i==77){
		page_77(master,&i);	
	}
	else if(i==78){
		page_78(master,&i);	
	}
	else if(i==79){
		page_79(master,&i);	
	}
	else if(i==80){
		page_80(master,&i);	
	}
	else if(i==81){
		page_81(master,&i);	
	}
	else if(i==82){
		page_82(master,&i);	
	}
	else if(i==83){
		page_83(master,&i);	
	}
	else if(i==84){
		page_84(master,&i);	
	}
	else if(i==85){
		page_85(master,&i);	
	}
	else if(i==86){
		page_86(master,&i);	
	}
	else if(i==87){
		page_87(master,&i);	
	}
	else if(i==88){
		page_88(master,&i);	
	}
	else if(i==89){
		page_89(master,&i);	
	}
	else if(i==90){
		page_90(master,&i);	
	}
	else if(i==91){
		page_91(master,&i);	
	}
	else if(i==92){
		page_92(master,&i);	
	}
	else if(i==93){
		page_93(master,&i);	
	}
	else if(i==94){
		page_94(master,&i);	
	}
	else if(i==95){
		page_95(master,&i);	
	}
	else if(i==96){
		page_96(master,&i);	
	}
	else if(i==97){
		page_97(master,&i);	
	}
	else if(i==98){
		page_98(master,&i);	
	}
	else if(i==99){
		page_99(master,&i);	
	}
	else if(i==100){
		page_100(master,&i);	
	}
	else if(i==101){
		page_101(master,&i);	
	}
	else if(i==102){
		page_102(master,&i);	
	}
	else if(i==103){
		page_103(master,&i);	
	}
	else if(i==104){
		page_104(master,&i);	
	}
	else if(i==105){
		page_105(master,&i);	
	}
	else if(i==106){
		page_106(master,&i);	
	}
	else if(i==107){
		page_107(master,&i);	
	}
	else if(i==10){
		page_108(master,&i);	
	}
	else if(i==109){
		page_109(master,&i);	
	}
	else if(i==110){
		page_110(master,&i);	
	}
	else if(i==111){
		page_111(master,&i);	
	}
	else if(i==112){
		page_112(master,&i);	
	}
	else if(i==113){
		page_113(master,&i);	
	}
	else if(i==114){
		page_114(master,&i);	
	}
	else if(i==115){
		page_115(master,&i);	
	}
	else if(i==116){
		page_116(master,&i);	
	}
	else if(i==117){
		page_117(master,&i);	
	}
	else if(i==118){
		page_118(master,&i);	
	}
	else if(i==119){
		page_119(master,&i);	
	}
	else if(i==120){
		page_120(master,&i);	
	}
	else if(i==121){
		page_121(master,&i);	
	}
	else if(i==122){
		page_122(master,&i);	
	}
	else if(i==123){
		page_123(master,&i);	
	}
	else if(i==124){
		page_124(master,&i);	
	}
	else if(i==125){
		page_125(master,&i);	
	}
	else if(i==126){
		page_126(master,&i);	
	}
	else if(i==127){
		page_127(master,&i);	
	}
	else if(i==128){
		page_128(master,&i);	
	}
	else if(i==129){
		page_129(master,&i);	
	}
	else if(i==130){
		page_130(master,&i);	
	}
	else if(i==131){
		page_131(master,&i);	
	}
	else if(i==132){
		page_132(master,&i);	
	}
	else if(i==133){
		page_133(master,&i);	
	}
	else if(i==134){
		page_134(master,&i);	
	}
	else if(i==135){
		page_135(master,&i);	
	}
	else if(i==136){
		page_136(master,&i);	
	}
	else if(i==137){
		page_137(master,&i);	
	}
	else if(i==138){
		page_138(master,&i);	
	}
	else if(i==139){
		page_139(master,&i);	
	}
	else if(i==140){
		page_140(master,&i);	
	}
	else if(i==141){
		page_141(master,&i);	
	}
	else if(i==142){
		page_142(master,&i);	
	}
	else if(i==143){
		page_143(master,&i);	
	}
	else if(i==144){
		page_144(master,&i);	
	}
	else if(i==145){
		page_145(master,&i);	
	}
	else if(i==146){
		page_146(master,&i);	
	}
	else if(i==147){
		page_147(master,&i);	
	}
	else if(i==148){
		page_148(master,&i);	
	}
	else if(i==149){
		page_149(master,&i);	
	}
	else if(i==150){
		page_150(master,&i);	
	}
	else if(i==151){
		page_151(master,&i);	
	}
	else if(i==152){
		page_152(master,&i);	
	}
	else if(i==153){
		page_153(master,&i);	
	}
	else if(i==154){
		page_154(master,&i);	
	}
	else if(i==155){
		page_155(master,&i);	
	}
	else if(i==156){
		page_156(master,&i);	
	}
	else if(i==157){
		page_157(master,&i);	
	}
	else if(i==158){
		page_158(master,&i);	
	}
	else if(i==159){
		page_159(master,&i);	
	}
	else if(i==160){
		page_160(master,&i);	
	}
	else if(i==161){
		page_161(master,&i);	
	}
	else if(i==162){
		page_162(master,&i);	
	}
	else if(i==163){
		page_163(master,&i);	
	}
	else if(i==164){
		page_164(master,&i);	
	}
	else if(i==165){
		page_165(master,&i);	
	}
	else if(i==166){
		page_166(master,&i);	
	}
	else if(i==167){
		page_167(master,&i);	
	}
	else if(i==168){
		page_168(master,&i);	
	}
	else if(i==169){
		page_169(master,&i);	
	}
	else if(i==170){
		page_170(master,&i);	
	}
	else if(i==171){
		page_171(master,&i);	
	}
	else if(i==172){
		page_172(master,&i);	
	}
	else if(i==173){
		page_173(master,&i);	
	}
	else if(i==174){
		page_174(master,&i);	
	}
	else if(i==175){
		page_175(master,&i);	
	}
	else if(i==176){
		page_176(master,&i);	
	}
	else if(i==177){
		page_177(master,&i);	
	}
	else if(i==178){
		page_178(master,&i);	
	}
	else if(i==179){
		page_179(master,&i);	
	}
	else if(i==180){
		page_180(master,&i);	
	}
	else if(i==181){
		page_181(master,&i);	
	}
	else if(i==182){
		page_182(master,&i);	
	}
	else if(i==183){
		page_183(master,&i);	
	}
	else if(i==184){
		page_184(master,&i);	
	}
	else if(i==185){
		page_185(master,&i);	
	}
	else if(i==186){
		page_186(master,&i);	
	}
	else if(i==187){
		page_187(master,&i);	
	}
	else if(i==188){
		page_188(master,&i);	
	}
	else if(i==189){
		page_189(master,&i);	
	}
	else if(i==190){
		page_190(master,&i);	
	}
	else if(i==191){
		page_191(master,&i);	
	}
	else if(i==192){
		page_192(master,&i);	
	}
	else if(i==193){
		page_193(master,&i);	
	}
	else if(i==194){
		page_194(master,&i);	
	}
	else if(i==195){
		page_195(master,&i);	
	}
	else if(i==196){
		page_196(master,&i);	
	}
	else if(i==197){
		page_197(master,&i);	
	}
	else if(i==198){
		page_198(master,&i);	
	}
	else if(i==199){
		page_199(master,&i);	
	}
	else if(i==200){
		page_200(master,&i);	
	}
	else if(i==201){
	    page_201(master,&i);	
	}
	else if(i==202){
	    page_202(master,&i);		
	}
	else if(i==203){
	    page_203(master,&i);		
	}
	else if(i==204){
		page_204(master,&i);	
	}
	else if(i==205){
		page_205(master,&i);	
	}
	else if(i==206){
		page_206(master,&i);	
	}
	else if(i==207){
		page_207(master,&i);	
	}
	else if(i==208){
		page_208(master,&i);	
	}
	else if(i==209){
		page_209(master,&i);	
	}
	else if(i==210){
		page_210(master,&i);	
	}
	else if(i==211){
		page_211(master,&i);	
	}
	else if(i==212){
		page_212(master,&i);	
	}
	else if(i==213){
		page_213(master,&i);	
	}
	else if(i==214){
	 	page_214(master,&i);	
	}
	else if(i==215){
		page_215(master,&i);	
	}
	else if(i==216){
		page_216(master,&i);	
	}
	else if(i==217){
		page_217(master,&i);	
	}
	else if(i==218){
		page_218(master,&i);	
	}
	else if(i==219){
		page_219(master,&i);	
	}
	else if(i==220){
		page_220(master,&i);	
	}
	else if(i==221){
		page_221(master,&i);	
	}
	else if(i==222){
		page_222(master,&i);	
	}
	else if(i==223){
		page_223(master,&i);	
	}
	else if(i==224){
		page_224(master,&i);	
	}
	else if(i==225){
		page_225(master,&i);	
	}
	else if(i==226){
		page_226(master,&i);	
	}
	else if(i==227){
		page_227(master,&i);	
	}
	else if(i==228){
		page_228(master,&i);	
	}
	else if(i==229){
		page_229(master,&i);	
	}
	else if(i==230){
		page_230(master,&i);	
	}
	else if(i==231){
		page_231(master,&i);	
	}
	else if(i==232){
		page_232(master,&i);	
	}
	else if(i==233){
		page_233(master,&i);	
	}
	else if(i==234){
		page_234(master,&i);	
	}
	else if(i==235){
		page_235(master,&i);	
	}
	else if(i==236){
		page_236(master,&i);	
	}
	else if(i==237){
		page_237(master,&i);	
	}
	else if(i==238){
		page_238(master,&i);	
	}
	else if(i==239){
		page_239(master,&i);	
	}
	else if(i==240){
		page_240(master,&i);	
	}
	else if(i==242){
		page_242(master,&i);	
	}
	else if(i==243){
		page_243(master,&i);	
	}
	else if(i==244){
		page_244(master,&i);	
	}
	else if(i==245){
		page_245(master,&i);	
	}
	else if(i==246){
		page_246(master,&i);	
	}
	else if(i==247){
		page_247(master,&i);	
	}
	else if(i==248){
		page_248(master,&i);	
	}
	else if(i==249){
		page_249(master,&i);	
	}
	else if(i==250){
		page_250(master,&i);	
	}
	else if(i==251){
		page_251(master,&i);	
	}
	else if(i==252){
		page_252(master,&i);	
	}
	else if(i==253){
		page_253(master,&i);	
	}
	else if(i==254){
		page_254(master,&i);	
	}
	else if(i==255){
		page_255(master,&i);	
	}
	else if(i==256){
		page_256(master,&i);	
	}
	else if(i==257){
		page_257(master,&i);	
	}
	else if(i==258){
		page_258(master,&i);	
	}
	else if(i==259){
		page_259(master,&i);	
	}
	else if(i==260){
		page_260(master,&i);	
	}
	else if(i==261){
		page_261(master,&i);	
	}
	else if(i==262){
		page_262(master,&i);	
	}
	else if(i==263){
		page_263(master,&i);	
	}
	else if(i==264){
		page_264(master,&i);	
	}
	else if(i==265){
		page_265(master,&i);	
	}
	else if(i==266){
		page_266(master,&i);	
	}
	else if(i==267){
		page_267(master,&i);	
	}
	else if(i==268){
		page_268(master,&i);	
	}
	else if(i==269){
		page_269(master,&i);	
	}
	else if(i==270){
		page_270(master,&i);	
	}
	else if(i==271){
		page_271(master,&i);	
	}
	else if(i==272){
		page_272(master,&i);	
	}
	else if(i==273){
		page_273(master,&i);	
	}
	else if(i==274){
		page_274(master,&i);	
	}
	else if(i==275){
		page_275(master,&i);	
	}
	else if(i==276){
		page_276(master,&i);	
	}
	else if(i==277){
		page_277(master,&i);	
	}
	else if(i==278){
		page_278(master,&i);	
	}
	else if(i==279){
		page_279(master,&i);	
	}
	else if(i==280){
		page_280(master,&i);	
	}
	else if(i==281){
		page_281(master,&i);	
	}
	else if(i==282){
		page_282(master,&i);	
	}
	else if(i==283){
		page_283(master,&i);	
	}
	else if(i==284){
		page_284(master,&i);	
	}
	else if(i==285){
		page_285(master,&i);	
	}
	else if(i==286){
		page_286(master,&i);	
	}
	else if(i==287){
		page_287(master,&i);	
	}
	else if(i==288){
		page_288(master,&i);	
	}
	else if(i==289){
		page_289(master,&i);	
	}
	else if(i==290){
		page_290(master,&i);	
	}
	else if(i==291){
		page_291(master,&i);	
	}
	else if(i==292){
		page_292(master,&i);	
	}
	else if(i==293){
		page_293(master,&i);	
	}
	else if(i==294){
		page_294(master,&i);	
	}
	else if(i==295){
		page_295(master,&i);	
	}
	else if(i==296){
		page_296(master,&i);	
	}
	else if(i==297){
		page_297(master,&i);	
	}
	else if(i==298){
		page_298(master,&i);	
	}
	else if(i==299){
		page_299(master,&i);	
	}
	else if(i==300){
		page_300(master,&i);	
	}
	else if(i==301){
	    page_301(master,&i);	
	}
	else if(i==302){
	    page_302(master,&i);		
	}
	else if(i==303){
	    page_303(master,&i);		
	}
	else if(i==304){
		page_304(master,&i);	
	}
	else if(i==305){
		page_305(master,&i);	
	}
	else if(i==306){
		page_306(master,&i);	
	}
	else if(i==307){
		page_307(master,&i);	
	}
	else if(i==308){
		page_308(master,&i);	
	}
	else if(i==309){
		page_309(master,&i);	
	}
	else if(i==310){
		page_310(master,&i);	
	}
	else if(i==311){
		page_311(master,&i);	
	}
	else if(i==312){
		page_312(master,&i);	
	}
	else if(i==313){
		page_313(master,&i);	
	}
	else if(i==314){
	 	page_314(master,&i);	
	}
	else if(i==315){
		page_315(master,&i);	
	}
	else if(i==316){
		page_316(master,&i);	
	}
	else if(i==317){
		page_317(master,&i);	
	}
	else if(i==318){
		page_318(master,&i);	
	}
	else if(i==319){
		page_319(master,&i);	
	}
	else if(i==320){
		page_320(master,&i);	
	}
	else if(i==321){
		page_321(master,&i);	
	}
	else if(i==322){
		page_322(master,&i);	
	}
	else if(i==323){
		page_323(master,&i);	
	}
	else if(i==324){
		page_324(master,&i);	
	}
	else if(i==325){
		page_325(master,&i);	
	}
	else if(i==326){
		page_326(master,&i);	
	}
	else if(i==327){
		page_327(master,&i);	
	}
	else if(i==328){
		page_328(master,&i);	
	}
	else if(i==329){
		page_329(master,&i);	
	}
	else if(i==330){
		page_330(master,&i);	
	}
	else if(i==331){
		page_331(master,&i);	
	}
	else if(i==332){
		page_332(master,&i);	
	}
	else if(i==333){
		page_333(master,&i);	
	}
	else if(i==334){
		page_334(master,&i);	
	}
	else if(i==335){
		page_335(master,&i);	
	}
	else if(i==336){
		page_336(master,&i);	
	}
	else if(i==337){
		page_337(master,&i);	
	}
	else if(i==338){
		page_338(master,&i);	
	}
	else if(i==339){
		page_339(master,&i);	
	}
	else if(i==340){
		page_340(master,&i);	
	}
	else if(i==341){
		page_341(master,&i);	
	}
	else if(i==342){
		page_342(master,&i);	
	}
	else if(i==343){
		page_343(master,&i);	
	}
	else if(i==344){
		page_344(master,&i);	
	}
	else if(i==345){
		page_345(master,&i);	
	}
	else if(i==346){
		page_346(master,&i);	
	}
	else if(i==347){
		page_347(master,&i);	
	}
	else if(i==348){
		page_348(master,&i);	
	}
	else if(i==349){
		page_349(master,&i);	
	}
	else if(i==350){
		page_350(master,&i);	
	}
	else if(i==351){
		page_351(master,&i);	
	}
	else if(i==352){
		page_352(master,&i);	
	}
	else if(i==353){
		page_353(master,&i);	
	}
	else if(i==354){
		page_354(master,&i);	
	}
	else if(i==355){
		page_355(master,&i);	
	}
	else if(i==356){
		page_356(master,&i);	
	}
	else if(i==357){
		page_357(master,&i);	
	}
	else if(i==358){
		page_358(master,&i);	
	}
	else if(i==359){
		page_359(master,&i);	
	}
	else if(i==360){
		page_360(master,&i);	
	}
	else if(i==361){
		page_361(master,&i);	
	}
	else if(i==362){
		page_362(master,&i);	
	}
	else if(i==363){
		page_363(master,&i);	
	}
	else if(i==364){
		page_364(master,&i);	
	}
	else if(i==365){
		page_365(master,&i);	
	}
	else if(i==366){
		page_366(master,&i);	
	}
	else if(i==367){
		page_367(master,&i);	
	}
	else if(i==368){
		page_368(master,&i);	
	}
	else if(i==369){
		page_369(master,&i);	
	}
	else if(i==370){
		page_370(master,&i);	
	}
	else if(i==371){
		page_371(master,&i);	
	}
	else if(i==372){
		page_372(master,&i);	
	}
	else if(i==373){
		page_373(master,&i);	
	}
	else if(i==374){
		page_374(master,&i);	
	}
	else if(i==375){
		page_375(master,&i);	
	}
	else if(i==376){
		page_376(master,&i);	
	}
	else if(i==377){
		page_377(master,&i);	
	}
	else if(i==378){
		page_378(master,&i);	
	}
	else if(i==379){
		page_379(master,&i);	
	}
	else if(i==380){
		page_380(master,&i);	
	}
	else if(i==381){
		page_381(master,&i);	
	}
	else if(i==382){
		page_382(master,&i);	
	}
	else if(i==383){
		page_383(master,&i);	
	}
	else if(i==384){
		page_384(master,&i);	
	}
	else if(i==385){
		page_385(master,&i);	
	}
	else if(i==386){
		page_386(master,&i);	
	}
	else if(i==387){
		page_387(master,&i);	
	}
	else if(i==388){
		page_388(master,&i);	
	}
	else if(i==389){
		page_389(master,&i);	
	}
	else if(i==390){
		page_390(master,&i);	
	}
	else if(i==391){
		page_391(master,&i);	
	}
	else if(i==392){
		page_392(master,&i);	
	}
	else if(i==393){
		page_393(master,&i);	
	}
	else if(i==394){
		page_394(master,&i);	
	}
	else if(i==395){
		page_395(master,&i);	
	}
	else if(i==396){
		page_396(master,&i);	
	}
	else if(i==397){
		page_397(master,&i);	
	}
	else if(i==398){
		page_398(master,&i);	
	}
	else if(i==399){
		page_399(master,&i);	
	}
	else if(i==400){
		page_400(master,&i);
		break;	
	}
	system("cls");
	}
	return 0;
}

