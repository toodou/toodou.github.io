#include <stdio.h>

int main(void){
	/*Ex 5-2: Declare Pointer */
	printf("Ex 5-2: Declare Pointer\n");
	int a = 5;
	float b = 1.2;
	int *p;
	float *q;
}