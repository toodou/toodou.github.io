#include <stdio.h>

int main(void){
	/*Ex 5-5: Operator +/- in Pointers */
	printf("Ex 5-5: Operator +/- in Pointers\n");
	int a = 5;
	int *p = &a;

	printf("The values of a and its address are %d and %p, respectively.\n", a, &a);
	printf("The values of p, p dereference and its address are %p, %d and %p, respectively.\n", p, *p, &p);

	printf("\nPLUS 1 ::\n");
	a = a + 1;
	p = p + 1;
	printf("The values of a and its address are %d and %p, respectively.\n", a, &a);
	printf("The values of p, p dereference and its address are %p, %d and %p, respectively.\n", p, *p, &p);
}