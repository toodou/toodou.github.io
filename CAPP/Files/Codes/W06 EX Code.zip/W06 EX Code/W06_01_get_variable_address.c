#include <stdio.h>

int main(){
	/*Ex 5-1: Get Variable Address */
	printf("Ex 5-1: Get Variable Address\n");
	int a;

	printf("Enter an integer number!\n", a);
	scanf("%d", &a);
	printf("a = %d\n", a);
	printf("a's address is %p\n", &a);
}