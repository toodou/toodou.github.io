#include <stdio.h>

int main (){
	/*Ex 5-6: Find your value*/
	/* find pointer in your memory*/

	// declare variable and pointer
	int a = 5;
	int *p = &a;

	// print value and address
	printf("Ex 5-6: Declare a Pointer - find pointer in your memory\n");
	printf("(1) The value of a = %d\n", a);
	printf("(2) The address of a in memory is %p\n", &a);
	printf("(3) The value of pointer p is %p\n", p);
	printf("(4) The pointing value of pointer p is %d\n", *p);
	printf("(5) The address of pointer p is %p\n", &p);

	// force integer pointer value store into a char pointer
	unsigned char* q = (char*) p;
	printf("(6) The value of pointer q is %p\n", q);
	printf("(7) The pointing value of pointer q is %d\n", *q);
	printf("(8) The address of pointer q is %p\n\n", &q);

	// set search range
	int range4search = 20;

	// set number for newline
	int newlineNum = 10;

	// print all values of selected memory locations
	printf("==== Memory overview ====");
	for (int i=-range4search; i<range4search; i++){
		if (i%newlineNum==0){
			// print the first address and value
			printf("\n%p\t %d\t", q+i,*(q+i));
		}else{
			// print value
			printf("%d\t", *(q+i));
		}
	}
} 
