#include <stdio.h>

int main(void){
	/*Ex 5-3: Get Variable Address2 */
	printf("Ex 5-3: Get Variable Address2\n");
	int a = 5;
	float b = 1.2;
	int *p = &a;
	float *q = &b;

	printf("a = %d (address: %p)\n", a, &a);
	printf("b = %f (address: %p)\n", b, &b);
	printf("p = %p\n", p);
	printf("q = %p\n", q);
}