#include <stdio.h>

int main(void){
	/*Ex 5-5: Get Variable Address2 */
	printf("Ex 5-4: Get Variable Address2\n");
	int a = 5;
	int *p = &a;

	printf("a = %d (address: %p)\n", a, &a);
	printf("p = %p\n", p);

	*p = 16;
	printf("*p = 16;\n");
	printf("a = %d (address: %p)\n", a, &a);
	printf("p = %p\n", p);

	a = 512;
	printf("a = 512;\n");
	printf("a = %d (address: %p)\n", a, &a);
	printf("p = %p\n", p);
}