#include <stdio.h>

int main(){
	/*Ex 7-5: array of pointers: print */
	printf("Ex 7-5: array of pointers: print\n");
	int arr1[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
	int arr2[5] = {11,12,13,14,15};
	int arr3[3] = {111,112,113};
	int i, j;

	int *arrOfPtr[3] = {arr1, arr2, arr3};
	int s[3] = {10,5,3};

	for (i=0; i<3; i++){
		for (j=0; j<s[i]; j++){
			printf("%d\t", arrOfPtr[i][j]);
		}
		printf("\n");
	}
}