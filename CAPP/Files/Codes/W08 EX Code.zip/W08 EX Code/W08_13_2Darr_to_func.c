#include <stdio.h>

void print2Darr(int (*p)[4], int row){
	// int (*p)[4] => change to other expressions...
	int i,j;
	for (i=0;i<row;i++){
		for (j=0;j<4;j++){
			printf("%d\t", p[i][j]); // change here!
		}
		printf("\n");
	}
}

int main(){
	/*Ex 7-13: 2D arr passing to func*/
	printf("Ex 7-13: 2D arr passing to func\n");
	int arr[3][4] = {{1,2,3,4},{5,6,7,8},{9,10,11,12}};
	print2Darr(arr, 3);
}