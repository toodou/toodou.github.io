#include <stdio.h>

int main(){
	/*Ex 7-6: ptr to 1darr*/
	printf("Ex 7-6: ptr to 1darr\n");
	int arr[10] = {11,12,13,14,15,16,17,18,19,20};
	int (*p)[10] = &arr;
	int i;

	for (i=0;i<10;i++){
		printf("arr[%d] = %d ||\t", i, arr[i]);
		if ((i+1)%5==0){
			printf("\n");
		}
	}

	printf("\n-----------------\n");

	for (i=0;i<10;i++){
		printf("(*p)[%d] = %d ||\t", i, *(p[0]+i));
		if ((i+1)%5==0){
			printf("\n");
		}
	}
	printf("\n");
}

