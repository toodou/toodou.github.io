#include <stdio.h>

int main(){
	/*Ex 7-10: length of array :: pointer*/
	printf("Ex 7-10: length of array :: pointer\n");
	int arr[4] = {10, 20, 30, 40};

	int *p = arr;
	printf("p  : %p\n", p); // int *
	printf("p+1: %p\n", p+1); // int *

	int (*q)[4] = &arr;
	printf("q  : %p\n", *q); // int *
	printf("q+1: %p\n", *(q+1)); // int *

	printf("length = *(q+1)-*(q+0): %d\n", *(q+1)-*(q+0));
}