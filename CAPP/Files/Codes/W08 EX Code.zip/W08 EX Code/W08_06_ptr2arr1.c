#include <stdio.h>

int main(){
	int arr[4]={0};
	int *p = arr;
	
	/*7-6 pointer to array*/
	printf("p    is %p, while p+1    is %p\n", p, p+1);
	printf("&arr is %p, while &arr+1 is %p\n", &arr, &arr+1);
}