#include <stdio.h>

int main(){
	/*Ex 7-9: length of array :: address*/
	printf("Ex 7-9: length of array :: address\n");
	int arr[4] = {10, 20, 30, 40};
	
	printf("arr:       %p\n", arr); // int (*)[4]
	printf("arr+1:     %p\n", arr+1); // int *
	printf("&arr+1:    %p\n", &arr+1); // int (*)[4]
	printf("*(&arr+1): %p\n", *(&arr+1)); // int *

	printf("length = *(&arr+1)-arr: %d\n", *(&arr+1)-arr);//*(&arr+0), *(&arr)
}