#include <stdio.h>

int main(){
	/*Ex 7-8: length of array :: sizeof()*/
	printf("Ex 7-8: length of array :: sizeof()\n");
	int arr[4] = {10, 20, 30, 40};
	
	printf("length = %d\n", sizeof(arr)/sizeof(arr[0]));
}