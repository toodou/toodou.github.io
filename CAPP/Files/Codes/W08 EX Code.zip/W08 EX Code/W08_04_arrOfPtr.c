#include <stdio.h>

int main(){
	/*Ex 7-4: array of pointers*/
	printf("Ex 7-4: array of pointers\n");
	int arr1[5] = {10, 20, 30, 40, 50};
	int arr2[2] = {3,5};
	int a = 5, i;

	int *arrOfPtr[4] = {arr1, &a, arr1+3};
	arrOfPtr[3] = arr2;

	for (i=0; i<4; i++){
		printf("%d\t%p\n", *arrOfPtr[i], arrOfPtr[i]);
	}
}