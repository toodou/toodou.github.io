#include <stdio.h>

int myMax(int a[], int s){
	int max = 0, i;
	for (i=0;i<s;i++){
		if (a[i]>max){
			max = a[i];
		}
	}
	return max;
}

int main(){
	/*Ex 7-1: ptr2ptr :: find max in an array*/
	printf("Ex 7-1: ptr2ptr :: find max in an array\n");
	int arr[5] = {51,41,311,211,110};
	int size = 5;
	printf("%d\n",myMax(arr,size));
}