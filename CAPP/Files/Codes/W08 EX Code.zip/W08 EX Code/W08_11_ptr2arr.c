#include <stdio.h>

int main(){
	int arr[4] = {11, 22, 33, 44};
	int (*ptr2arr)[4] = &arr;
	int *arrOfptr[4];
	arrOfptr[0] = arr;

	/*Ex 7-11: ptr to arr*/
	printf("Ex 7-11: ptr to arr\n");
	printf("arr location:%p\n", &arr);
	printf("------\n");
	for (int i=0;i<4;i++){
		printf("ptr2arr+%d: %p (= %p)\n", i, ptr2arr+i, *(ptr2arr+i));
	}
	printf("------\n");
	for (int i=0;i<4;i++){
		printf("ptr2arr[0]+%d: %p (= %d)\n", i, ptr2arr[0]+i, *(ptr2arr[0]+i));
	}

}