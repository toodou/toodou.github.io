#include <stdio.h>

int main(){
	/*Ex 7-7: ptr to 2darr*/
	printf("Ex 7-7: ptr to 2darr\n");
	int i;
	int arr[3][4] = {{1,2,3,4},{5,6,7,8},{9,10,11,12}};
	
	printf("(1) arr, arr+1, arr+2\n");
	// address: arr, arr+1, arr+2
	printf("First row: \t%p\nSecond row:\t%p\nThird row: \t%p\n", arr, arr+1, arr+2);

	printf("(2) (*p)[4] = arr+2\n");
	int (*p)[4] = arr+2;
	for (i=0; i<4; i++){
		printf("p+%d: %p\t", i, p+i); // 16 bytes; 4 elements
	}
	printf("\n");
	for (i=0; i<4; i++){
		printf("(*p)+%d: %p\t", i, (*p)+i); // 4 bytes; 1 element
	}
	printf("\n");
	for (i=0; i<4; i++){
		printf("*((*p)+%d): %d\t", i, *((*p)+i)); // 4 bytes; 1 element; get value
	}
	printf("\n");

	printf("(3) &arr+1\n");
	// &arr+1 => the next address that can store an arr[3][4],
	// referring to the next address of the last element of arr[3][4].
	printf("&arr+1: %p\n", &arr+1);
	
	printf("(4) *q = arr[1]; q+i\n");
	// arr[1] => the second row => an array: int [4]
	printf("arr[1]: %p\n", arr[1]);
	int *q = arr[1]; // arr+1
	for (i=0; i<4; i++){
		printf("q+%d: %p\t", i, q+i);
	}
	printf("\n");

	printf("(5) arr[1] vs *(arr[1]) vs *(arr[1]+2)\n");
	printf("arr[1] = %p\n", arr[1]);
	printf("*(arr[1]) = %d\n", *(arr[1]));
	printf("*(arr[1]+2) = %d\n", *(arr[1]+2));

	printf("(6) how to get the value of arr[2][3]\n");
	printf("arr[2][3] = %d\n", arr[2][3]);
	printf("*(arr[2]+3) = %d\n", *(arr[2]+3));
	printf("*(*(arr+2)+3) = %d\n", *(*(arr+2)+3));
}


