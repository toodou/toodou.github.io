#include <stdio.h>

int main(){
	int arr[4] = {11, 22, 33, 44};
	int (*ptr2arr)[4] = &arr;
	int *arrOfptr[4];
	arrOfptr[0] = arr;

	/*Ex 7-12: arr of ptr*/
	printf("Ex 7-12: arr of ptr\n");
	printf("arr location:%p\n", &arr);
	printf("------\n");
	for (int i=0;i<4;i++){
		printf("arrOfptr+%d: %p (= %p)\n", i, arrOfptr+i, *(arrOfptr+i));
	}
	printf("------\n");
	for (int i=0;i<4;i++){
		printf("arrOfptr[0]+%d: %p (= %d)\n", i, arrOfptr[0]+i, *(arrOfptr[0]+i));
	}

}