#include <stdio.h>

void my_max(int a[], int s, int **ptrmax){
	*ptrmax = a;
	int i;
	for (i=0;i<s;i++){
		if (a[i]>**ptrmax){
			*ptrmax = &a[i];
		}
	}
}

int main(){
	/*Ex 7-3: ptr2ptr :: find max in an array*/
	printf("Ex 7-3: ptr2ptr :: find max in an array\n");
	int arr[5] = {51,41,311,211,110};
	int size = 5, *max;
	my_max(arr, size, &max);
	printf("max: %d\n",*max);
}