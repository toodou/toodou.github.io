#include <stdio.h>
#include <string.h>

typedef struct{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
} Flight;

int main(){
	/*Ex 13-4: typedef with struct method 1*/
	Flight EK367;
}