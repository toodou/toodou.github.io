#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int put_flightNo(Flight *F, char flightNoList[][6], int size){
	int idx;
	for (idx=0; idx<size; idx++){
		strcpy(F[idx].flightNo, flightNoList[idx]);
	}
}

int print_flightNo(Flight *F, int size){
	int idx;
	for (idx=0; idx<size; idx++){
		printf("Flight Number is %s.\n", F[idx].flightNo);
	}
}

int main(){
	/*Ex 13-17: struct array in function*/
	printf("/*Ex 13-17: struct array in function*/\n");
	int i;
	char EmiratesFlightInfo[3][6] = {"EK367", "EK366", "EK362"};
	Flight Emirates[10];

	put_flightNo(Emirates, EmiratesFlightInfo, 3);
	print_flightNo(Emirates, 3);
}