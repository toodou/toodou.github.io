#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[10];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};
typedef struct flight Flight;

struct airlines{
	char airline[10];
	Flight flight[10];
};
typedef struct airlines Airlines;


int put_flightNo(Airlines *A, char flightNoList[][6], int size){
	int idx;
	for (idx=0; idx<size; idx++){
		strcpy(A->flight[idx].flightNo, flightNoList[idx]);
		//printf("Flight Number is %s.\n", A.flight[idx].flightNo);
	}
}

int print_flightNo(Airlines A, int size){
	int idx;
	for (idx=0; idx<size; idx++){
		printf("Flight Number is %s.\n", A.flight[idx].flightNo);
	}
}

int main(){
	/*Ex 13-19: nested struct*/
	printf("/*Ex 13-19: nested struct*/\n");
	int i;

	Airlines Emirates;

	char EmiratesFlightInfo[6][6] = {"EK367", "EK366", "EK362", "EK031", "EK943", "EK358"};

	put_flightNo(&Emirates, EmiratesFlightInfo, 6);
	printf("Flight Number is %s.\n", Emirates.flight[0].flightNo);
	printf("-----------------------\n");
	print_flightNo(Emirates, 6);
}