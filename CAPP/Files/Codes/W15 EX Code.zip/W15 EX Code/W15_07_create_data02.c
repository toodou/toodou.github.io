#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-7: create struct and fill with values*/
	printf("/*Ex 13-7: create struct and fill with values */\n");
	Flight EK367;

	strcpy(EK367.flightNo, "EK367");
	strcpy(EK367.airline, "Emirates Airline");
	strcpy(EK367.origin, "TPE");
	strcpy(EK367.destination, "DXB");
	EK367.frequency = 7;
	EK367.sitCapacity = 459;
	EK367.duration = 9.917;

	printf("Airline: %s\nFlight Number: %s\n", EK367.flightNo, EK367.airline);
	printf("Origin -> Destination: %s -> %s\n", EK367.origin, EK367.destination);
	printf("Flight Frequency per Week: %d\n", EK367.frequency);
	printf("Sit Capacity: %d\n", EK367.sitCapacity);
	printf("Flight Time: %5.2lf hr\n", EK367.duration);
}