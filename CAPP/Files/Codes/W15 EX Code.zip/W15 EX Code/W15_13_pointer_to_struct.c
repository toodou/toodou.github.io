#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-13: pointer to struct*/
	printf("/*Ex 13-13: pointer to struct*/\n");
	Flight EK367 = {"EK367", "Emirates Airline", "TPE", "DXB", 7, 459, 9.917};
	Flight *r = &EK367;

	printf("Flight Number (%s) is operated by %s.\n", (*r).flightNo, (*r).airline);
}