#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-14: pointer to struct with arrow*/
	printf("/*Ex 13-14: pointer to struct with arrow*/\n");
	Flight EK367 = {"EK367", "Emirates Airline", "TPE", "DXB", 7, 459, 9.917};
	Flight *r = &EK367, *s;

	s = r;
	printf("Flight Number (%s) is operated by %s.\n", s->flightNo, s->airline);
}