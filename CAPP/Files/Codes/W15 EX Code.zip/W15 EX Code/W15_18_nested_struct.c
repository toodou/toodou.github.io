#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[10];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};
typedef struct flight Flight;

struct airlines{
	char airline[10];
	Flight flight[10];
};
typedef struct airlines Airlines;

int main(){
	/*Ex 13-18: nested struct*/
	printf("/*Ex 13-18: nested struct*/\n");
	int i;

	Airlines Emirates;

	char EmiratesFlightInfo[6][6] = {"EK367", "EK366", "EK362", "EK031", "EK943", "EK358"};

	strcpy(Emirates.airline, "Emirates");
	strcpy(Emirates.flight[0].airline, "Emirates");
	strcpy(Emirates.flight[0].flightNo, "EK366");
	printf("%s-%s-%s\n", Emirates.airline, Emirates.flight[0].airline, Emirates.flight[0].flightNo);
}