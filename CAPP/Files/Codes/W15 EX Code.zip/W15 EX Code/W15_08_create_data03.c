#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-8: create two struct data*/
	Flight EK367, EK366;

	strcpy(EK367.flightNo, "EK367");
	strcpy(EK367.airline, "Emirates Airline");
	strcpy(EK367.origin, "TPE");
	strcpy(EK367.destination, "DXB");
	EK367.frequency = 7;
	EK367.sitCapacity = 459;
	EK367.duration = 9.917;

	strcpy(EK366.flightNo, "EK366");
	strcpy(EK366.airline, "Emirates Airline");
	strcpy(EK366.origin, "DXB");
	strcpy(EK366.destination, "TPE");
	EK366.frequency = 7;
	EK366.sitCapacity = 459;
	EK366.duration = 7.917;
}