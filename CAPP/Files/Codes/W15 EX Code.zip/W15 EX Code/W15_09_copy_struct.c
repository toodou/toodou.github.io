#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-9: copy struct data*/
	printf("/*Ex 13-9: copy struct data*/\n");
	Flight EK367;

	strcpy(EK367.flightNo, "EK367");
	strcpy(EK367.airline, "Emirates Airline");
	strcpy(EK367.origin, "TPE");
	strcpy(EK367.destination, "DXB");
	EK367.frequency = 7;
	EK367.sitCapacity = 459;
	EK367.duration = 9.917;

	Flight EK364 = EK367;
	
	printf("Airline: %s\nFlight Number: %s\n", EK364.flightNo, EK364.airline);
	printf("Origin -> Destination: %s -> %s\n", EK364.origin, EK364.destination);
	printf("Flight Frequency per Week: %d\n", EK364.frequency);
	printf("Sit Capacity: %d\n", EK364.sitCapacity);
	printf("Flight Time: %5.2lf hr\n", EK364.duration);
}