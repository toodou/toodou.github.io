#include <stdio.h>

typedef int INT;

int main(){
	/*Ex 13-3: typedef */
	printf("/*Ex 13-3: typedef */\n");
	INT i = 10;
	printf("%d\n", i);
}