#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int get_flightNo(Flight F){
	printf("Flight Number is %s.\n", F.flightNo);
}

int get_flightNo_arrow(Flight *F){
	printf("Flight Number is %s.\n", F->flightNo);
}

int main(){
	/*Ex 13-15: struct to function*/
	printf("/*Ex 13-15: struct to function*/\n");
	Flight EK367 = {"EK367", "Emirates Airline", "TPE", "DXB", 7, 459, 9.917};
	Flight *p = &EK367;

	get_flightNo(EK367);
	get_flightNo_arrow(p);
}