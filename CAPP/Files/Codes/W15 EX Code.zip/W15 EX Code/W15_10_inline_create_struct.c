#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-10: inline fill struct data*/
	printf("/*Ex 13-10: inline fill struct data*/\n");
	Flight EK367 = {"EK367", "Emirates Airline", "TPE", "DXB", 7, 459, 9.917}, 
		   EK366 = {"EK366", "", "DXB", "TPE", 0, 0, 7.917};
	
	strcpy(EK366.airline, EK367.airline);
	EK366.frequency = EK367.frequency;
	EK366.sitCapacity = EK367.sitCapacity;
	printf("Airline: %s\nFlight Number: %s\n", EK366.flightNo, EK366.airline);
	printf("Flight Frequency per Week: %d\n", EK366.frequency);
	printf("Sit Capacity: %d\n", EK366.frequency);
	printf("Flight Time: %5.2lf hr\n", EK366.duration);
}