#include <stdio.h>
#include <string.h>

struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
};

typedef struct flight Flight;

int main(){
	/*Ex 13-16: struct array*/
	printf("/*Ex 13-16: struct array*/\n");
	int i;
	Flight Emirates[10];

	strcpy(Emirates[0].flightNo, "EK367");
	strcpy(Emirates[1].flightNo, "EK366");
	strcpy(Emirates[2].flightNo, "EK362");

	for (i=0; i<3; i++){
		printf("Flight Number: %s\n", Emirates[i].flightNo);
	}
}