#include <stdio.h>
#define LENGTH 10

int main(void)
{
	/*Ex 2-7: 1-D array */
	/* 1-D array */
	int arr[LENGTH] = {0};
    int i, c = 0;

	printf("Ex 2-7: 1-D array\n");

    printf("original array value: ");
    for(i = 0; i < LENGTH; i++) {
        printf("%d ", arr[i]);
    }

	printf("\nsum of value from the first");
    for(i = 0; i < LENGTH; i++) {
        c += i;
        arr[i] = c;
    }

    printf("\nshow result: ");
    for(i = 0; i < LENGTH; i++) {
        printf("%d ", arr[i]);
    }
    putchar('\n');

	return 0;
}