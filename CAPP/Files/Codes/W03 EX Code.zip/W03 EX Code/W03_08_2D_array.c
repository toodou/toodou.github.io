#include <stdio.h>
#define ROW 4
#define COLUMN 6

int main(void)
{
	/*Ex 2-8: 2-D array */
	/* 2-D array */
	int arr[ROW][COLUMN] = {0};
    int i, j;

	printf("Ex 2-8: 2-D array\n");

    printf("original array value: ");
    for(i = 0; i < ROW; i++) {
        for (j = 0; j <COLUMN; j++) {
            arr[i][j] = i*j;
        }
    }

    printf("show result: \n");
    for(i = 0; i < ROW; i++) {
        for (j = 0; j <COLUMN; j++) {
            printf("%d\t", arr[i][j]);
        }
        putchar('\n');
    }
	return 0;
}