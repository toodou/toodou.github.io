#include <stdio.h>

int main(void)
{
	/*Ex 2-5: Control - continue*/
	/* Control - continue*/

	printf("Ex 2-5: Control - continue\n");
	for (int a = 0; a < 5; a++) {
        printf("%d\t", a);
        if (a == 3) {
            continue;
            printf("Hello world!\n");
        }
    } 
    printf("Ending!");

	return 0;
}