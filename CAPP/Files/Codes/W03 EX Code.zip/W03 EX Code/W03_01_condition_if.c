#include <stdio.h>

int main(void)
{
	/*Ex 2-1: If else */
	/* If else if else */
	int age;

	printf("Ex 2-1: If else\n");
	printf("How old are you?\n");
	scanf("%d", &age);
	if (age<18){
		printf("He or she is not yet an adult!\n");
	} else if (age<20){
		printf("He or she cannot vote yet!\n");
	} else{
		printf("He or she can vote and bear full legal responsibility!\n");
	}
	return 0;
}