#include <stdio.h>

int main(void)
{
	/*Ex 2-3: Switch case */
	/* Switch case */
    char gpa;

	printf("Ex 2-3: Switch case\n");
	printf("Wanna to know your score? Key in your GPA here!\n");
	scanf("%c", &gpa);

	switch (gpa){
		case 'A':
            printf("Your score ranges from 90-100!");
            break;
        case 'B':
            printf("Your score ranges from 80-90!");
            break;
        case 'C':
            printf("Your score ranges from 70-80!");
            break;
        case 'D':
            printf("Your score ranges from 60-70!");
            break;
        default:
            printf("Your score belows 60!");
            break;
	}
	return 0;
}