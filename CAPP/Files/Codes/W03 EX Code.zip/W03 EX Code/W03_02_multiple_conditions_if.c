#include <stdio.h>

int main(void)
{
	/*Ex 2-2: Multiple If else */
	/* Multiple If else if else */
	int age;

	printf("Ex 2-2: Multiple If else\n");
	printf("How old are you?\n");
	scanf("%d", &age);
	if (age < 12){
		printf("You are child!");
	} else if (age >= 12 && age < 20){
		printf("You are adolescent!");
	} else if (age >= 20 && age < 65) {
		//age >= 20 && age < 65
		printf("You are middle age!");
	} else {
        printf("You are old people!");
    }
	return 0;
}