#include <stdio.h>

int main(void)
{
	/*Ex 2-6: Control - goto */
	/* Control - goto */
    int count = 0;
    int a;

	printf("Ex 2-6: Control - goto\n");
    START:
	for (a = 0; a < 5; a++) {
        printf("%d\t", a);
        if (a == 3 && count<3) {
            printf("Hello world!\n");
            count += 1;
            goto START;
        } else {
            continue;
        }
    } 
    printf("Ending!");

	return 0;
}