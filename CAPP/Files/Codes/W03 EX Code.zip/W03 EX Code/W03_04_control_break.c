#include <stdio.h>

int main(void)
{
	/*Ex 2-4: Control - break*/
	/* Control - break*/

	printf("Ex 2-4: Control - break\n");
	for (int a = 0; a < 5; a++) {
        printf("%d\t", a);
        if (a == 3) {
            break;
            printf("Hello world!\n");
        }
    } 
    printf("Ending!");

	return 0;
}