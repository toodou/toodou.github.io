#include <stdio.h>

int main(void)
{
	/*Ex 1-7: While loop */
	/* Test While loop */
	int i = 1;

	printf("Ex 1-7: While loop\n");
	while (i<10){
		printf("%d ", i);
		i++;
	}
	return 0;
}

