#include <stdio.h>

int main(void)
{
	/*Ex 1-4: Formatting the numbers*/
	/* print variables */
	printf("Ex 1-4: [float] Formatting the numbers\n");
	printf("%9.2f%s", 31415.926535,"\n");
	printf("%09.2f%s", 31415.926535,"\n");
	printf("%+9.2f%s", -3.1415926535,"\n");
	printf("%3.0f%s", 123.456,"\n");
	printf("%3.2f%s", 123.456,"\n");
	printf("%02.2f%s", 123.456,"\n");

	return 0;
}