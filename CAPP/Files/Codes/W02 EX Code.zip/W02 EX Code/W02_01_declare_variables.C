#include <stdio.h>

int main(void)
{
	/* Ex 1-1: Declare Variable */
	// declare variables
	int a = 3; /*整數*/
	float b = 1.5; //浮點數
	double c = 1.2; //double
	char d = 'T'; //character
	return 0;
}




