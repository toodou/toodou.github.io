#include <stdio.h>

int main(void)
{
	/*Ex 1-6: For loop */
	/* Test For loop */
	int i;

	printf("Ex 1-6: For loop\n");

	for (i=1; i<10; i++){
		printf("%d ", i);
	}
	return 0;
}