#include <stdio.h>

int main(void)
{
	/* Ex 1-2: Print Variables */
	/* print variables */
	printf("Ex 1-2: Print Variable\n");
	printf("Hola! Buenos Dias!\n");
	printf("100*2 = 200\n");
	printf("\tHello! My name is Mike. My major is \"Computer Science.\"\n");
	printf("You can direct print an 'A' in this way, but have you ever tried by an input '\\x41'? \x41\n\n");
	return 0;
}




