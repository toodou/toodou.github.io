#include <stdio.h>

int main(void)
{
	/*Ex 1-3: Formatting the numbers*/
	/* print variables */
	printf("Ex 1-3: [int] Formatting the numbers\n");
	printf("%10d%s", 20210808,"\n");
	printf("%+d%s", -20210808,"\n");
	printf("%-d%s", -20210808,"\n");
	printf("%d%s", -20210808,"\n");
	printf("%010d%s", 20210808,"\n");
	return 0;
}