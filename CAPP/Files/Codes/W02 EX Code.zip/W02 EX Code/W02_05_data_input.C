#include <stdio.h>

int main(void)
{
	/*Ex 1-5: Data input */
	/* scan variables */
	int num1, num2;

	printf("Ex 1-5: Data input\n");
	printf("Please key two numbers with a space!\n");
	//1 2
	scanf("%d %d", &num1, &num2);
	printf("Your numbers are: %d, %d\n", num1, num2);
	printf("size of var %d - %d %d", sizeof(num1), sizeof(num2), num1+num2);
	return 0;
}