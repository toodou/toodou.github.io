#include <stdio.h>

int my_factorial(int n){
	if(n<=1){
		return 1;
	} else {
		return n*my_factorial(n-1);
	}
}

int main(void){
	/*Ex 4-2: Recursive function*/
	/* Factorial - recursive version*/
	printf("Ex 4-2: Factorial :: Recursive function\n");
	printf("5! = %d\n", my_factorial(5));
	printf("8! = %d\n", my_factorial(8));
	printf("10! = %d\n", my_factorial(10));
}