#include <stdio.h>
//global variables
int a = 1;
int b = 5;
char c[2] = "s";

int foo(void){
	int a = 3;
	int x = 10;

	printf("\nWithin foo function!\n");
	printf("a = %d; b = %d; c = %s; x = %d\n\n", a, b, c, x);
}

int main(void){
	/*Ex 4-1: Global and local variables */
	/* Demonstration - The differences between global and local variables*/

	//local variables
	float h = 1.67;
	float w = 75;
	
	printf("Ex 4-1: Global and local variables\n");
	printf("Before calling foo function!\n");
	printf("a = %d; b = %d; c = %s\n", a, b, c); //x = %d, x
	printf("h = %f; w = %f\n", h, w);

	foo();

	printf("After calling foo function!\n");
	printf("a = %d; b = %d; c = %s\n", a, b, c);
	printf("h = %f; w = %f\n", h, w);
}