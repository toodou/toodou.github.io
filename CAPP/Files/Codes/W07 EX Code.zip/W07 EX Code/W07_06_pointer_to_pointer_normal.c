#include <stdio.h>

int main(){
	/*Ex 6-6: Pointer to Pointer */
	printf("Ex 6-6: Pointer to Pointer\n");
	int a = 5;
	int *p = &a;
	int **q= &p;

	printf("int a = %d\n", a);
	printf("var\tname\tvalue\taddress\n");
	printf("int\ta\t%d\t%p\n", a, &a);
	printf("ptr\tp\t%p (=%d)\t%p\n", p, *p, &p);
	printf("ptr\tq\t%p (=%d)\t%p\n", q, **q, &q);
	printf("\t\t%p (*q)\n", *q);
}