#include <stdio.h>

int main(){
	/*Ex 6-1: Null Pointer */
	printf("Ex 6-1: Null Pointer\n");
	int *p = 0;
	int *q = NULL;
}