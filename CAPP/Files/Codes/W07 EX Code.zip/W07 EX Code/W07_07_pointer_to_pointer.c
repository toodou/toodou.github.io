#include <stdio.h>
#include "print_status.c"

int main(){
	/*Ex 6-7: Pointer to Pointer2 */
	printf("Ex 6-7: Pointer to Pointer2\n");
	int a = 5, b = 13;
	int *p = &a, *q = &b;
	int **r= &p, **s= &q;
	
	//print_status(a, b, p, q, r, s);

	printf("(1) a = %d\n", a);
	printf("(2) b = %d\n", b);

	printf("(3) %d\n", *p + **s);
	printf("(4) %d\n", **r * *q);

	*p = 30;
	printf("(5) %d\n", *p + *q);
	**r = 40;
	printf("(6) %d\n", **r + **s);
	print_status(a, b, p, q, r, s);
	*s = &a;
	printf("(7) %d\n", *p + *q);
	print_status(a, b, p, q, r, s);
	*q = 100;
	printf("(8) %d\n", **r + **s);
	print_status(a, b, p, q, r, s);
}

