#include <stdio.h>

int main(){
	/*Ex 6-6: Pointer to Pointer */
	printf("Ex 6-6: Pointer to Pointer\n");
	int a = 5;
	int *p = &a;
	int **q= &p;
}