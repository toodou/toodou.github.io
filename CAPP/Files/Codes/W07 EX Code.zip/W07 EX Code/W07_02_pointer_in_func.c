#include <stdio.h>

int foo(int *addr){
	printf("[in-foo-pre] address: %p\n", addr);
	*addr = 100;
	printf("[in-foo-post] address: %p\n", addr);
}

int goo(int val){
	printf("[in-goo-pre] val = %d (address: %p)\n", val, &val);
	val = 200;
	printf("[in-goo-post] val = %d (address: %p)\n", val, &val);
}

int main(){
	/*Ex 6-3: Passing Pointer/Value into Function */
	printf("Ex 6-3: Passing Pointer/Value into Function\n");
	int a = 5;
	printf("[main-initialize] a = %d (address: %p)\n", a, &a);
	foo(&a);
	printf("\n[main-after-foo] a = %d (address: %p)\n", a, &a);
	goo(a);
	printf("\n[main-after-goo] a = %d (address: %p)\n", a, &a);
}


