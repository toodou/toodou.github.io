#include <stdio.h>

int foo(int ptr[10], int sizeofArray){
	for (int i=0; i<sizeofArray; i++){
		printf("%d\t", ptr[i]);
	}
}

int main(){
	/*Ex 6-4: Array to Function */
	printf("Ex 6-4: Array to Function\n");
	int arr[10] = {0,1,2,3,4,5,6,7,8,9};

	foo(arr, 10);
}