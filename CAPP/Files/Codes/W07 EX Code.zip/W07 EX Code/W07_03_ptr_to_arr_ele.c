#include <stdio.h>

int main(){
	/*Ex 6-3: Pointer to Array Element */
	printf("Ex 6-3: Pointer to Array Element\n");
	int arr[5] = {5,10,15,20,0};
	int *p = &arr[0];

	for (int i=0; i<5; i++){
		printf("%d\t", *(p+i));
	}
}