#include <stdio.h>
#include <string.h>

int main(void)
{
	/*Ex 10-10: Length & Copy*/
    int i = 84;
    char c1[7] = "hello!";

	printf("Ex 10-10: Length & Copy\n");
    printf("The original string: %s (length: %d; size: %d; int i: %c)\n", c1, strlen(c1), sizeof(c1), i);
    printf("RAM address: %p %p\n", &i, &c1);
    
    strcpy(c1, "A-Wond");
    printf("The strcpy's string: %s (length: %d; size: %d; int i: %c)\n", c1, strlen(c1), sizeof(c1), i);
	printf("RAM address: %p %p\n", &i, &c1);
	
	return 0;
}