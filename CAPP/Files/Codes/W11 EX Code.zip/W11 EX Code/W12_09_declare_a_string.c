#include <stdio.h>
#include <string.h>

int main(){
	/*Ex 10-9: Declare a String */
	printf("Ex 10-9: Declare a String\n");
	char str1[5] = "hello";
	char str2[6] = "hello";
	char str3[50] = "hello";
	char str4[50] = "";

	printf("str1[5] = %s\n", str1);
	printf("str2[6] = %s\n", str2);
	printf("str3[50]  = %s\n", str3);
	printf("str4[50]  = %s\n", str4);
}