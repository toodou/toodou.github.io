#include <stdio.h>
#include <string.h>

int main(void)
{
	/*Ex 10-11: strncpy */
    char c1[4] = "abc";
    char c2[7] = "hello!";

	printf("Ex 10-11: strncpy\n");
    printf("The original string: %s (length: %d; size: %d; c1: %s)\n", c2,  strlen(c2), sizeof(c2), c1);
    printf("RAM address: %p %p\n", &c1, &c2);
    
    strncpy(c2, "A-Wonder", 6);
    printf("[count= 6] The strncpy's string: %s (length: %d; size: %d; c1: %s)\n", c2, strlen(c2), sizeof(c2), c1);
	
	strncpy(c2, "A-Wonder", 7);
    printf("[count= 7] The strncpy's string: %s (length: %d; size: %d; c1: %s)\n", c2, strlen(c2), sizeof(c2), c1);
	
	strncpy(c2, "A-Wonder", 8);
    printf("[count= 8] The strncpy's string: %s (length: %d; size: %d; c1: %s)\n", c2, strlen(c2), sizeof(c2), c1);
	
	strncpy(c2, "A-Wonder", 9);
    printf("[count= 9] The strncpy's string: %s (length: %d; size: %d; c1: %s)\n", c2, strlen(c2), sizeof(c2), c1);
	
	strncpy(c2, "A-Wonder", 10);
    printf("[count=10] The strncpy's string: %s (length: %d; size: %d; c1: %s)\n", c2, strlen(c2), sizeof(c2), c1);

    strncpy(c2, "A-Wonder", 11);
    printf("[count=11] The strncpy's string: %s (length: %d; size: %d; c1: %s)\n", c2, strlen(c2), sizeof(c2), c1);
}