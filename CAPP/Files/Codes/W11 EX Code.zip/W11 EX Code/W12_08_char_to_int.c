#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	/*Ex 10-8: Char to Int */
	printf("Ex 10-8: Char to Int\n");

	char c='9';
	int m1, m2, m3;

	m1 = atoi(&c);
	printf("by using atoi() => %d\n", m1);

	m2 = (int)c;
	printf("by using (int)c => %d\n", m2);

	m3 = (int)c-48;
	printf("by using (int)c-48 => %d\n", m3);
}