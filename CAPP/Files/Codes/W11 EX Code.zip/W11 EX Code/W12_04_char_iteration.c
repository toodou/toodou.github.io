#include <stdio.h>

int main(){
	/*Ex 10-4: Char Iteration */
	printf("Ex 10-4: Char Iteration\n");
	int i;
	char c = 'a';
	
	for (i=0; i<26; i++){
		printf("%c\t", c+i);
	}
}