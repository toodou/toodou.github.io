#include <stdio.h>

int main(void)
{
	/*Ex 10-5: putchar, getchar */
    char c4gc;

	printf("Ex 10-5: putchar, getchar\n");
    printf("Plz enter a word: \n");
    c4gc = getchar();

    putchar(c4gc); //print the variable c4gc
    putchar('\n'); //newline
}