#include <stdio.h>

int main(){
	/*Ex 10-1: Declare a Char Variable*/
	printf("Ex 10-1: Declare a Char Variable\n");

	char c1 = 'a';
	char c2 = 'b';
}