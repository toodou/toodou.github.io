#include <stdio.h>

int main(void)
{
	/*Ex 10-6: putchar, getchar */
    char c4gc1, c4gc2;

	printf("Ex 10-6: putchar, getchar\n");
    printf("Plz enter a word: \n");
    c4gc1 = getchar();
    c4gc2 = getchar();
    putchar(c4gc1); //print the variable c4gc1
    putchar(c4gc2); //print the variable c4gc2
    putchar('\n'); //newline
}