#include <stdio.h>

int main(){
	/*Ex 10-2: Read and Print a Char */
	printf("Ex 10-2: Read and Print a Char\n");

	char c;
	printf("Please enter a char:\n");
	scanf("%c", &c);
	printf("The char is %c\a\n", c);
}