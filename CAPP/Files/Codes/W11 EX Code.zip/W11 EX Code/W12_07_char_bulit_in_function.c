#include <stdio.h>
#include <ctype.h>

int main(void)
{
	/*Ex 10-7: Char Built-in Function */
	char c1 = '1', c2 = 'a', c3 = 'A';
	int i = 10, j = 'B';

	printf("Ex 10-7: Char Built-in Function\n");
	printf("[isalnum test] i=10	  %d\n", isalnum(i));
	printf("[isalnum test] c1='1' %d\n", isalnum(c1));
	printf("[isalnum test] j='B'  %d\n\n", isalnum(j));

	printf("[isalpha test] i=10   %d\n", isalpha(i));
	printf("[isalpha test] c1='1' %d\n\n", isalpha(c1));

	printf("[isdigit test] i=10   %d\n", isdigit(i));
	printf("[isdigit test] c1='1' %d\n\n", isdigit(c1));

	printf("[islower test] c2='a' %d\n", islower(c2));
	printf("[islower test] c3='A' %d\n\n", islower(c3));

	printf("[isupper test] c2='a' %d\n", isupper(c2));
	printf("[isupper test] c3='A' %d\n\n", isupper(c3));

    printf("[isspace test] ' '    %d\n", isspace(' '));
    printf("[isspace test] '\t'   %d\n\n", isspace('\t'));

    printf("[tolower test] c3='A' %c\n", tolower(c3));
    printf("[toupper test] c2='a' %c\n", toupper(c2));
}