#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-3: malloc in block */
	printf("Ex 12-3: malloc in block\n");
	int size = 5, i;

	if(1){ // if else block
		int *p = (int*) malloc(sizeof(int)*size);

		printf("-------------after malloc-------------\n");
		printf("%10d (%p)\n", *p, &p);

		// assign value
		printf("--------------------------------------\n");
		printf("index |    value   | memory location\n");
		printf("--------------------------------------\n");
		for (i=0; i<size; i++){
			p[i] = i+100;
			printf("%5d | %10d | %p\n", i, p[i], &p[i]);
		}

		printf("-------------after assign-------------\n");
		printf("%10d (%p)\n", *p, &p);
	}
	// printf("%10d (%p)\n", *p, &p); // error: 'p' undeclared (first use in this function)
}