#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-7: memory allocation with calloc() */
	printf("Ex 12-7: memory allocation with calloc()\n");
	int size = 5, i;
	int *p = (int*) calloc(size, sizeof(int));

	printf("-------------after calloc-------------\n");
	printf("%10d (%p)\n", *p, &p);

	printf("--------------------------------------\n");
	printf("index |    value   | memory location\n");
	printf("--------------------------------------\n");
	for (i=0; i<size; i++){
		printf("%5d | %10d | %p\n", i, p[i], &p[i]);
	}

	printf("--------------value check-------------\n");
	printf("%10d (%p)\n", *p, &p);

	printf("--------------value check-------------\n");
	printf("%10d (%p)\n", p[0], &p[0]);
	printf("%10d (%p)\n", p[2], &p[2]);

	free(p); // safe and okay
	
	printf("--------------safty check-------------\n");
	printf("%10d (%p)\n", p[0], &p[0]);
	printf("%10d (%p)\n", p[2], &p[2]);
	p = 0;
	printf("%10d (%p)\n", p, &p);
}