#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-5: free memory and call after */
	printf("Ex 12-5: free memory and call after\n");
	int size = 5, i;
	int *p = (int*) malloc(sizeof(int)*size);

	printf("-------------after malloc-------------\n");
	printf("%10d (%p)\n", *p, &p);

	printf("--------------------------------------\n");
	printf("index |    value   | memory location\n");
	printf("--------------------------------------\n");
	for (i=0; i<size; i++){
		p[i] = i+10;
		printf("%10d (%p)\n", p[i], &p[i]);
	}

	printf("-------------after assign-------------\n");
	printf("%10d (%p)\n", *p, &p);

	printf("----------------free()----------------\n");
	free(p); // safe and okay
	
	printf("----------call after free()-----------\n");
	printf("%10d (%p)\n", p[0], &p[0]);
	printf("%10d (%p)\n", p[2], &p[2]);
}