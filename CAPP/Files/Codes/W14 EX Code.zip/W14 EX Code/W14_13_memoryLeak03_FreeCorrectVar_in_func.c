#include <stdio.h>
#include <stdlib.h>

int *expand(int size){
	int *exp = (int*) malloc(sizeof(int)*size);
	return exp;
}

int main(){
	/*Ex 12-13: Memory Leak (function) 03 :: free correct variable? */
	int *arr = expand(10);
	free(arr); // Is it safe? Yes.
	arr = 0;
}