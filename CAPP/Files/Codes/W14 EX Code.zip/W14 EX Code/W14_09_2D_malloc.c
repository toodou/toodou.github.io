#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-9: memory allocation for 2D array with malloc() */
	printf("Ex 12-9: memory allocation for 2D array with malloc()\n");
	int col = 4, row = 2, i, j;

	// using pointer-to-pointer
	int **arr = (int**) malloc(sizeof(int*)*row);

	// using malloc again to add memory space for column elements
	for (i=0; i<row; i++){
		arr[i] = (int*) malloc(sizeof(int)*col);
	}

	printf("-----------after malloc------------\n");
	// print values
	for (i=0; i<row; i++){
		for (j=0; j<col; j++){
			printf("(%d,%d) %8d (%p)\t", i, j, arr[i][j], &arr[i][j]);
		}
		putchar('\n');
	}

	printf("--------------free()---------------\n");
	// free memory space
	free(arr);
}