#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-17: Common Mistake 02 :: free twice */
	int size = 10;
	int *p = (int*) malloc(sizeof(int)*size);

	int *q = p;
	printf("%p %p\n", p, q);

	// free memory space
	free(q); // safe and okay
	free(p); // that is redundant!
}