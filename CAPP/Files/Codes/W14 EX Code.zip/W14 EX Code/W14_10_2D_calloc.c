#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-10: memory allocation for 2D array with calloc() */
	printf("Ex 12-10: memory allocation for 2D array with calloc()\n");
	int col = 4, row = 2, i, j;

	// using pointer-to-pointer
	int **arr = calloc(row, sizeof(int*));
	
	// using calloc again to add memory space for column elements
	for (i=0; i<row; i++){
		arr[i] = calloc(col, sizeof(int));
	}

	printf("-----------after calloc------------\n");
	// print values
	for (i=0; i<row; i++){
		for (j=0; j<col; j++){
			printf("(%d,%d) %2d (%p)\t", i, j, arr[i][j], &arr[i][j]);
		}
		putchar('\n');
	}

	printf("--------------free()---------------\n");
	// free memory space
	free(arr);
}