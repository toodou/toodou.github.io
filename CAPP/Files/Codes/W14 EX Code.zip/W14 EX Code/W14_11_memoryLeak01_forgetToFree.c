#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-11: Memory Leak 01 :: forget to free memory */
	int size = 10;
	int *p = (int*) malloc(sizeof(int)*size);

	// after malloc
	printf("%10d (%p)\n", *p, &p);

	// free memory space
	// ...
}