#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-1: malloc */
	printf("Ex 12-1: malloc \n");
	int size = 5, i;
	int *p = (int*) malloc(sizeof(int)*size);

	printf("-------------after malloc-------------\n");
	printf("%10d (%p)\n", *p, &p);

	// print value
	printf("--------------------------------------\n");
	printf("index |    value   | memory location\n");
	printf("--------------------------------------\n");
	for (i=0; i<size; i++){
		printf("%5d | %10d | %p\n", i, p[i], &p[i]);
	}
}