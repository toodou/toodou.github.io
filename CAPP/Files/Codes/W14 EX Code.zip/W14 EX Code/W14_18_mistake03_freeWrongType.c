#include <stdio.h>
#include <stdlib.h>
int main(){
	/*Ex 12-18: Common Mistake 03 :: free wrong type */
	int size = 10;
	int *p = (int*) malloc(sizeof(int)*size);
	// free memory space
	free(p); // safe and okay
	free(size); // => warning: passing argument 1 of 'free' makes pointer from integer without a cast [-Wint-conversion]
}