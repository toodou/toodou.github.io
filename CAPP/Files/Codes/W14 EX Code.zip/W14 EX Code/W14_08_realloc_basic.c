#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-8: memory REallocation with realloc() */
	printf("Ex 12-8: memory REallocation with realloc()\n");
	int size = 5, i;
	int *arr1 = (int*) malloc(sizeof(int)*size);

	printf("-------------after malloc-------------\n");
	printf("%10d (%p)\n", *arr1, &arr1);

	printf("--------------------------------------\n");
	printf("index |    value   | memory location\n");
	printf("--------------------------------------\n");
	// assign value
	for (i=0; i<size; i++){
		arr1[i] = i+10;
		printf("%5d | %10d | %p\n", i, arr1[i], &arr1[i]);
	}

	printf("-------------after assign-------------\n");
	printf("%10d (%p)\n", *arr1, &arr1);

	printf("------------after realloc()-----------\n");
	int *arr2 = realloc(arr1, sizeof(int)*size*2);

	// print value
	printf("--------------------------------------\n");
	printf("index |    value    | memory location\n");
	printf("--------------------------------------\n");
	for (int i=0; i<size*2; i++){
		printf("%5d | %11d | %p\n", i, arr2[i], &arr2[i]);
	}

	printf("--------------value check-------------\n");
	printf("%10d (%p)\n", arr1[0], &arr1[0]);
	printf("%10d (%p)\n", arr2[2], &arr2[2]);

	printf("----------------free()----------------\n");
	// free(arr1); <= that is unnecessary
	free(arr2); // safe and okay

	printf("--------------safty check-------------\n");
	printf("%10d (%p)\n", arr1[0], &arr1[0]);
	printf("%10d (%p)\n", arr2[2], &arr2[2]);
}