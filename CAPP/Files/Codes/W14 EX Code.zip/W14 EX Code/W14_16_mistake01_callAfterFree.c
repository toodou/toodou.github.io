#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-16: Common Mistake 01 :: call after free */
	int size = 10;
	int *p = (int*) malloc(sizeof(int)*size);

	// free memory space
	free(p); // safe and okay
	p = 0;

	// call again
	printf("%d\n", p[1]); // occurs error
}