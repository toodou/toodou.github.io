#include <stdio.h>
#include <stdlib.h>

int expand(int *exp, int size){
	exp = (int*) malloc(sizeof(int)*size);
}

int main(){
	/*Ex 12-14: Memory Leak (function) 04 :: free correct variable? */
	int *arr;
	expand(arr, 10);
	free(arr); // Is it safe? No.
}