#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-12: Memory Leak 02 :: too large memory allocation */
	int size = 100000;
	int *p = (int*) malloc(sizeof(int)*size);

	// after malloc
	printf("Ex 12-12: Memory Leak 02 :: too large memory allocation\n");
	printf("%10d (%p)\n", *p, &p);

	// free memory space
	free(p); // safe and okay
	p = 0;
}