#include <stdio.h>
#include <stdlib.h>

int main(){
	/*Ex 12-4: free memory  */
	printf("Ex 12-4: free memory\n");
	int size = 5, i;
	int *p = (int*) malloc(sizeof(int)*size);

	printf("-------------after malloc-------------\n");
	printf("%10d (%p)\n", *p, &p);

	// assign value
	printf("--------------------------------------\n");
	printf("index |    value   | memory location\n");
	printf("--------------------------------------\n");
	for (i=0; i<size; i++){
		p[i] = i+10;
		printf("%5d | %10d | %p\n", i, p[i], &p[i]);
	}

	printf("-------------after assign-------------\n");
	printf("%10d (%p)\n", *p, &p);

	printf("----------------free()----------------\n");
	free(p); // safe and okay
}