#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "W16_header.h"

int main(){
	/*Ex 14-15: insert at the first position*/
	printf("/*Ex 14-15: insert at the first position*/\n");

	// original linked list
	Node *link = 0;
	push(&link, 'H');
	push(&link, 'E');
	push(&link, 'D');
	printNode(link);

	// new Node a
	Node a;
	a.alpha = 'A';
	a.next = 0;

	// set Node ptrs for search and insertion
	Node *head = 0, *pre = 0, *now = 0, *new = 0;
	
	// store the memory space of the new Node a
	new = &a;
	// store the starting point of original linked list
	head = link;
	// store the first Node and second Node location
	pre = new;
	now = head;
	// compare the alphabet ranking
	if (pre->alpha < now->alpha){
		printf("insert at the beginning\n");
	}else{
		printf("insert at other positions\n");
	}

	// insert at the begining
	head = new;
	new->next = now;

	// print all nodes
	printNode(head);
	pre = 0;
}