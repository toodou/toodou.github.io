#include <stdio.h>
#include <string.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void bulitLLByLoop(const char letter[], Node act[]){
	int i;
	Node *now = &act[0];
	for (i=0; i<strlen(letter); i++){
		now->alpha = letter[i];
		if (i==strlen(letter)-1){
			now->next = 0;
		}else{
			now->next = &act[i+1];
		}
		printf("[%d] %c, %p\n", i, now->alpha, now->next);
		now = now -> next;
	}
}

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-8: insert*/
	printf("/*Ex 14-8: insert*/\n");

	// build a linked list
	char letter[4] = {'A','G','O'};
	char target = 'G', letter4insert = 'X';
	Node act[3], *cur = &act[0], x;
	bulitLLByLoop(letter, act);
	printNode(&act[0]);

	// search position for insertion
	while(cur){
		if(cur->alpha == target){
			printf("found\n");
			// copy the memory location
			Node *loc = cur->next;
			x.alpha = letter4insert;
			x.next = loc;
			// reconnect to the original linked list
			cur->next = &x;
			break;
		}
		cur = cur -> next;
	}
	if(cur == 0){
		printf("cannot find\n");
	}
	printNode(&act[0]);
}