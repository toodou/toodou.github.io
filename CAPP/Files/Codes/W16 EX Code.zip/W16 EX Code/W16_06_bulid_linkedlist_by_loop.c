#include <stdio.h>
#include <string.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-6: build linked list by loop*/
	printf("/*Ex 14-6: build linked list by loop*/\n");

	int i;
	char letter[4] = {'A','C','T'};
	Node act[3];
	Node *now = &act[0];

	for (i=0; i<3; i++){
		now->alpha = letter[i];
		if (i==2){
			now->next = 0;
		}else{
			now->next = &act[i+1];
		}
		printf("[%d] %c, %p\n", i, now->alpha, now->next);
		now = now -> next;
	}

	printNode(&act[0]);
	putchar('\n');
	printf("%p %p %p\n", act[0].next, act[1].next, act[2].next);
}