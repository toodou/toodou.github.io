#include <stdio.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

int main(){
	/*Ex 14-4: print all nodes within linked list*/
	printf("/*Ex 14-4: print all nodes within linked list*/\n");

	Node a, c, t;
	a.alpha = 'A';
	a.next = &c;
	a.next -> alpha = 'C';
	a.next -> next = &t;
	a.next -> next -> alpha = 'T'; // t.alpha = 'T';
	a.next -> next -> next = 0;

	Node *now = &a;

	while(now){ // now != 0
		printf("%c\t", now->alpha);
		now  = now -> next;
	}
	putchar('\n');
}