#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "W16_header.h"

int main(){
	/*Ex 14-19: insert node in the ordered linked list with scanf*/
	printf("/*Ex 14-19: insert node in the ordered linked list with scanf*/\n");

	// empty linked list
	Node *head = 0;
	char endSym = '*';

	printf("plz enter a alphabet character (end loop: enter *) >>> ");
	scanf("%c", &endSym);
	
	while (endSym!='*'){
		// store a new Node
		Node *new = (Node*)malloc(sizeof(Node));
		new->alpha = endSym;
		new->next = 0;

		// search the position for insertion
		Node *pre = 0, *now = head;

		while (now && now->alpha < new->alpha){
			// store the first Node and second Node location
			pre = now;
			now = now->next;
		}
		if (pre==0){
			// if the node (to be inserted) at the beginning
			new->next = head;
			head = new;
		} else{
			// if the node (to be inserted) at the other positions
			pre->next = new;
			new->next = now;
		}
		// print all nodes
		printf("current status: ");
		printNode(head);

		printf("plz enter a alphabet character (end loop: enter *) >>> ");
		scanf("%c", &endSym);
	}

	// free memory space
	release(&head);
}