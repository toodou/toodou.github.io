#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "W16_header.h"

int main(){
	/*Ex 14-17: insert node in the ordered linked list (non-first position)*/
	printf("/*Ex 14-17: insert node in the ordered linked list (non-first position)*/\n");

	// original linked list
	Node *link = 0;
	push(&link, 'H');
	push(&link, 'E');
	push(&link, 'D');
	printNode(link);

	// new Node g
	Node g;
	g.alpha = 'G';
	g.next = 0;

	// set Node ptrs for search and insertion
	Node *head = link, *pre = 0, *now = head, *new = &g;
	
	while (now && now->alpha < new->alpha){
		// store the first Node and second Node location
		pre = now;
		now = now->next;
	}
	if (pre==0){
		// if the node (to be inserted) at the beginning
		new->next = head;
		head = new;
	}else{
		// if the node (to be inserted) at the other positions
		pre->next = new;
		new->next = now;
	}

	printNode(head);
}