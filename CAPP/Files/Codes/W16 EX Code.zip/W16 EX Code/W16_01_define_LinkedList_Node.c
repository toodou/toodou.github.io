#include <stdio.h>
#include <string.h>

typedef struct flight{
	char flightNo[10];
	char airline[30];
	char origin[4], destination[4];
	int frequency, sitCapacity;
	double duration;
} Flight;

typedef struct node{
	Flight data;
	struct node *next;
} Node;

int main(){
	/*Ex 14-1: define a node of linked list */
	return 0;
}