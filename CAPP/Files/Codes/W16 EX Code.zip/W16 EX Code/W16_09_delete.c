#include <stdio.h>
#include <string.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void bulitLLByLoop(const char letter[], Node act[]){
	int i;
	Node *now = &act[0];
	for (i=0; i<strlen(letter); i++){
		now->alpha = letter[i];
		if (i==strlen(letter)-1){
			now->next = 0;
		}else{
			now->next = &act[i+1];
		}
		printf("[%d] %c, %p\n", i, now->alpha, now->next);
		now = now -> next;
	}
}

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-9: delete*/
	printf("/*Ex 14-9: delete*/\n");

	// build a linked list
	char letter[5] = {'W','E','A','R'};
	char target = 'E';
	Node act[4], *now = &act[0], *pre = &act[0], x;
	bulitLLByLoop(letter, act);
	printNode(&act[0]);

	// search position for deletion
	while(now){
		if(now->alpha == target){
			pre->next = now->next;
			break;
		}
		pre = now;
		now = now -> next;
	}
	if(now == 0){
		printf("cannot find\n");
	}
	printNode(&act[0]);
}