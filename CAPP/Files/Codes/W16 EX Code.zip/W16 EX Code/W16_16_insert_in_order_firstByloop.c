#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "W16_header.h"

int main(){
	/*Ex 14-16: insert at the first position by loop*/
	printf("/*Ex 14-16: insert at the first position by loop*/\n");

	// original linked list
	Node *link = 0;
	push(&link, 'H');
	push(&link, 'E');
	push(&link, 'D');
	printNode(link);

	// new Node a
	Node a;
	a.alpha = 'A';
	a.next = 0;

	// set Node ptrs for search and insertion
	Node *head = link, *pre = 0, *now = head, *new = &a;
	
	while (now && now->alpha < new->alpha){
		// store the first Node and second Node location
		pre = now;
		now = now->next;
	}
	if (pre==0){
		// if the node (to be inserted) at the beginning
		new->next = head;
		head = new;
	}

	// print all nodes
	printNode(head);
}