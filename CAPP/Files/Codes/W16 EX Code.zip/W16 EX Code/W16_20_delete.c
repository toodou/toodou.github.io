#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "W16_header.h"

int main(){
	/*Ex 14-20: delete node in the ordered linked list*/
	printf("/*Ex 14-20: delete node in the ordered linked list*/\n");

	// bulid linked list
	Node *link = 0;
	push(&link, 'B');
	push(&link, 'H');
	push(&link, 'E');
	push(&link, 'D');
	printNode(link);

	// new Node a
	Node h;
	h.alpha = 'H';
	h.next = 0;

	// set Node ptrs for search and deletion
	Node *head = link, *pre = 0, *now = head, *new = &h;
	
	while (now && now->alpha != new->alpha){
		// store the first Node and second Node location
		pre = now;
		now = now->next;
	}
	if (pre==0){
		// if the node (to be deleted) at the beginning
		head = head->next;
		free(now);
	} else{
		// if the node (to be deleted) at the other positions
		pre->next = now->next;
		free(now);
	}

	// print all nodes
	printNode(head);
	// free memory space
	release(&head);
}