#include <stdio.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void printNode(const Node *head){
	while(head){ // head != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-5: print all nodes within linked list in function*/
	printf("/*Ex 14-5: print all nodes within linked list in function*/\n");
	
	Node a, c, t;
	a.alpha = 'A';
	a.next = &c;
	a.next -> alpha = 'C';
	a.next -> next = &t;
	a.next -> next -> alpha = 'T'; // t.alpha = 'T';
	a.next -> next -> next = 0;

	printNode(&a);
}