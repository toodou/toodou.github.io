#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void bulitLLByLoop(const char letter[], Node act[]){
	int i;
	Node *now = &act[0];
	for (i=0; i<strlen(letter); i++){
		now->alpha = letter[i];
		if (i==strlen(letter)-1){
			now->next = 0;
		}else{
			now->next = &act[i+1];
		}
		printf("[%d] %c, %p\n", i, now->alpha, now->next);
		now = now -> next;
	}
}

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c ", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

void push(Node **stack, char letter){
	Node *temp = (Node*) malloc (sizeof(Node));
	temp->alpha = letter;
	temp->next = *stack;
	*stack = temp;
}

void pop(Node **stack){
	Node *temp = *stack;
	*stack = temp->next;
	free(temp);
}

void release(Node **stack){
	while(*stack){
		Node *temp = *stack;
		*stack = temp->next;
		free(temp);
	}
}