#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-11: dynamic memory allocation for multiple node*/
	printf("/*Ex 14-11: dynamic memory allocation for multiple node*/\n");

	int i;
	Node *head = 0, *now = 0;
	
	for (i=0; i<5; i++){
		// declare a memory space for a node by DMA
		now = (Node*) malloc (sizeof(Node));
		now->alpha = 'A'+i;
		now->next = 0;
		// add to a linked list
		now->next = head;
		head = now;
		printNode(head);
	}
	
	// printNode(head);
	printf("-------------\n");

	// free memory space
	while(head){
		Node *del = head;
		head = head->next;
		printNode(head);
		free(del);
	}

	printNode(head);
}