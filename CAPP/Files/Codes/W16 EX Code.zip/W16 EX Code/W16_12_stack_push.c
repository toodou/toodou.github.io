#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

void push(Node **stack, char letter){
	Node *temp = (Node*) malloc (sizeof(Node));
	temp->alpha = letter;
	temp->next = *stack;
	*stack = temp;
}

int main(){
	/*Ex 14-12: push*/
	printf("/*Ex 14-12: push*/\n");

	Node *head = 0;
	
	push(&head, 'G');
	push(&head, 'N');
	push(&head, 'A');
	push(&head, 'K');
	push(&head, 'M');
	push(&head, 'A');
	push(&head, 'T');

	printNode(head);
}