#include <stdio.h>
#include <string.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void bulitLLByLoop(const char letter[], Node act[]){
	int i;
	Node *now = &act[0];
	for (i=0; i<strlen(letter); i++){
		now->alpha = letter[i];
		if (i==strlen(letter)-1){
			now->next = 0;
		}else{
			now->next = &act[i+1];
		}
		printf("[%d] %c, %p\n", i, now->alpha, now->next);
		now = now -> next;
	}
}

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-7: search*/
	printf("/*Ex 14-7: search*/\n");

	// build a linked list
	char letter[4] = {'A','G','O'};
	char target = 'G';
	Node act[3], *now = &act[0];
	bulitLLByLoop(letter, act);
	printNode(&act[0]);

	// search position
	while(now){
		if(now->alpha == target){
			printf("found\n");
			break;
		}
		now = now -> next;
	}
	if(now == 0){
		printf("cannot find\n");
	}
}