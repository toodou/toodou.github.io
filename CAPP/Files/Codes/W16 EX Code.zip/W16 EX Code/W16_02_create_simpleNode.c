#include <stdio.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

int main(){
	/*Ex 14-2: create a node of linked list */
	printf("/*Ex 14-2: create a node of linked list*/\n");
	Node a;
	a.alpha = 'A';
	printf("a is %c (ptr = %p).\n", a.alpha, a.next);
	printf("memory location of a is %p\n", &a);
}