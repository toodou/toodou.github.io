#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

void printNode(const Node *head){
	while(head){ // now != 0
		printf("%c\t", head->alpha);
		head  = head -> next;
	}
	putchar('\n');
}

int main(){
	/*Ex 14-10: dynamic memory allocation for one node*/
	printf("/*Ex 14-10: dynamic memory allocation for one node*/\n");

	Node *head = 0, *now = 0;
	
	// declare a memory space for a node by DMA
	now = (Node*) malloc (sizeof(Node));
	now->alpha = 'A';
	now->next = 0;
	// add to a linked list
	head = now;
	printNode(head);
	// free memory space
	free(head);
}