#include <stdio.h>

typedef struct node{
	char alpha;
	struct node *next;
} Node;

int main(){
	/*Ex 14-3: create a simple linked list*/
	printf("/*Ex 14-3: create a simple linked list*/\n");
	
	Node a, c;
	a.alpha = 'A';
	a.next = &c;
	// c.alpha = 'C'
	a.next -> alpha = 'C';
	printf("a is %c, where c is %c.\n", a.alpha, c.alpha);
	return 0;
}