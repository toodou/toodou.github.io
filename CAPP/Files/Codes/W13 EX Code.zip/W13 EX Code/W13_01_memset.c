#include <stdio.h>
#include <string.h>

int main(void)
{
	/*Ex 11-1: String Basic */
	/* String - memset*/
	char s[50];

	printf("Ex 11-1: String - memset\n");
	strcpy(s, "Do you want to build a snow man?");
	printf("string before: %s\n", s);

	memset(s, '*', 10);
	printf("string after: %s\n", s);
	
	return 0;
}