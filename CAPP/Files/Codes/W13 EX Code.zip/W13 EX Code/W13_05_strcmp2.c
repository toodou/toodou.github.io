#include <stdio.h>
#include <string.h>

int main(void)
{
	/*Ex 11-5: String Basic */
	/* String - strcmp2*/
    char s1[4] = "wow";
	char s2[4] = "Wow";

	int res = strcmp(s1, s2);

	printf("Ex 11-5: String - strcmp2\n");
    printf("Result: %d \n", res);

    if (res==0){
    	printf("Two strings are equal!\n");
    }else{
    	printf("Two strings are different!\n");
    }
	return 0;
}