#include <stdio.h>
#include <string.h>

int main(void)
{
	/*Ex 11-3: String Basic */
	/* String - Cat2*/
    char c1[50];
	char c2[50];

	printf("Ex 11-3: String - Cat2\n");
	strcpy(c1, "Hello");
	strcpy(c2, " world!");
    printf("c1 string: %s \nc2 string: %s\n", c1,  c2);

    strncat(c1, c2, 6);

    printf("Answer: %s\n", c1);
	printf("c1 size: %d; c1 length: %d\n", sizeof(c1), strlen(c1));
	
	return 0;
}