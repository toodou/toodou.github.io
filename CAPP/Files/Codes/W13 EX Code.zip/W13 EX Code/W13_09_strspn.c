#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LENGTH 80

int main() {

	/*Ex 11-9: String Basic */
	/* String - strspn*/
	char str1[LENGTH];
	char str2[LENGTH];

	printf("Ex 11-9: String - strspn\n");
	printf("Plz enter a string: ");
	fgets(str1, LENGTH, stdin);

	printf("Plz enter a string for searching: ");
	fgets(str2, LENGTH, stdin);

	// delete the last character (newline char)
	str1[strlen(str1) - 1] = '\0';//xxxxx  \0
	str2[strlen(str2) - 1] = '\0';//hella  \0

	size_t loc = strspn(str1, str2);

	if (loc == strlen(str1)) {
		printf("The second string completely appears in the first one!\n");
	}
	else {
		printf("The different characters start from %lu\n", loc);
	}

	system("pause");
}