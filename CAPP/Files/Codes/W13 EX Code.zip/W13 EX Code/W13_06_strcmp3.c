#include <stdio.h>
#include <string.h>

int main(void)
{
	/*Ex 11-6: String Basic */
	/* String - strcmp3*/
    char s1[4] = "Wow";
	char s2[4] = "wow";

	int res = strcmp(s1, s2);

	printf("Ex 11-6: String - strcmp3\n");
    printf("Result: %d \n", res);

    if (res==0){
    	printf("Two strings are equal!\n");
    }else{
    	printf("Two strings are different!\n");
    }
	return 0;
}