#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LENGTH 80

int main ()
{
	/*Ex 11-11: String Basic */
	/* String - strpbrk*/
	char str1[LENGTH];
	char str2[LENGTH];

	printf("Ex 11-11: String - strpbrk\n");
	printf("Plz enter a string: ");
	fgets(str1, LENGTH, stdin);

	printf("Plz enter a string for searching: ");
	fgets(str2, LENGTH, stdin);
	char *ret;

	// delete the last character (newline char)
	printf("%s %d--", str1, strlen(str1));
	str1[strlen(str1) - 1] = '\0';
	str2[strlen(str2) - 1] = '\0';
	printf("%s %d--", str1, strlen(str1));
	ret = strpbrk(str1, str2);
	printf("%s %d--", str1, strlen(str1));
	if(ret) {
		printf("First matching character: %c\n", *ret);
	}
	else 
	{
		printf("Character not found\n");
	}
	system("pause");
}