#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	/*Ex 11-7: String Basic */
	/* String - fgets, puts*/
	char s4fg[50];

	printf("Ex 11-7: String - fgets, puts\n");

	printf("Plz enter a word: \n");
	fgets(s4fg, sizeof(s4fg), stdin); //fgets has auto newline functionality
	
	puts(s4fg);
	
	system("pause");
}