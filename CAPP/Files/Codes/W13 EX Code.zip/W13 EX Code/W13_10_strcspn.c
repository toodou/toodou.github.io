#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LENGTH 80

int main() {

	/*Ex 11-10: String Basic */
	/* String - strcspn*/
	char str1[LENGTH];
	char str2[LENGTH];

	printf("Ex 11-10: String - strcspn\n");
	printf("Plz enter a string: ");
	fgets(str1, LENGTH, stdin);

	printf("Plz enter a string for searching: ");
	fgets(str2, LENGTH, stdin);

	// delete the last character (newline char)
	str1[strlen(str1) - 1] = '\0';
	str2[strlen(str2) - 1] = '\0';

	size_t loc = strcspn(str1, str2);

	if (loc == strlen(str1)) {
		printf("For all characters in the second string cannot find in the first one! (loc value: %lu)\n", loc);
	}
	else {
		printf("At least one character in the second string is found in the location %lu of the first string.\n", loc);
	}

	system("pause");
}