#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LENGTH 80

int main(void)
{
	/*Ex 11-8: String Basic */
	/* String - strstr*/
	char str1[LENGTH];
	char str2[LENGTH];

	printf("Ex 11-8: String - strstr\n");
	printf("input string: ");
	fgets(str1, LENGTH, stdin);

	printf("string for searching: ");
	fgets(str2, LENGTH, stdin);

	// delete the last character (newline char)
	str2[strlen(str2) - 1] = '\0';

	char* loc = strstr(str1, str2);

	if (loc == NULL) {
		printf("The second string cannot be found in the first one!\n");
	} else {
		printf("The second string completely appears in the location %lu of the first one!\n", loc - str1);
	}
	system("pause");
}