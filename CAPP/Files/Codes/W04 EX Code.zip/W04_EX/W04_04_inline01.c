#include <stdio.h>

int main(void){
	/*Ex 3-4: Inline Function */
	/* inline - hello*/
	printf("Ex 3-4: Inline Function\n");
	printf("Call hello function!\n");
	inline int hello(void){ printf("Hello world!\n");}
	hello();
}