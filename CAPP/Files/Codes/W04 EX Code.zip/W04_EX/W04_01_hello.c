#include <stdio.h>

int hello(void){
	printf("Hello world!");
	return 0;
}

int main(void){
	/*Ex 3-1: Define Function */
	/* call - hello*/
	printf("Call hello function!\n");
	hello();
	return 0;
}