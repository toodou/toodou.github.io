#include <stdio.h>

int main(void){
	/*Ex 3-5: Inline Function */
	/* inline - BMI Calculator*/
	float height = 1.67;
	float weight = 75;
	float BMI;

	printf("Ex 3-5: Inline Function\n");
	printf("BMI Calculator\n");

	inline float sqr(float a){return a*a;}
	inline float div(float a, float b){return a/b;}

	float height2 = sqr(height);
	BMI = div(weight, height2);

	printf("%2.2f\n", BMI);
}