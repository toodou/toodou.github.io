#include <stdio.h>

int add(int a, int b){
	printf("%d", a+b);
	return 0;
}

int main(void){
	/*Ex 3-2: Define Function */
	/* call - addition*/
	printf("Call add function!\n");
	add(52, 4);
	return 0;
}