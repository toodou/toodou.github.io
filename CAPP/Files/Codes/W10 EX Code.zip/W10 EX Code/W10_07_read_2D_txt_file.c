#include <stdio.h>

int main(){
	/*Ex 9-7: read a 2D text file*/
	printf("Ex 9-7: read a 2D text file\n");
	int i,j,ROW=29,COL=6;
	int a[ROW][COL];
	char s[ROW][10];
	// read a file
	FILE *text = fopen("pop_ntc.txt", "r");
	for (i=0;i<ROW;i++){
		for (j=0;j<COL+1;j++){
			if (j==0){
				fscanf(text, "%s", &s[i][j]);
			}else{
				fscanf(text, "%d", &a[i][j-1]);
			}
		}
	}
	fclose(text);
	// print array element
	for (i=0;i<ROW;i++){
		printf("%s\t",s[i]);
		for (j=0;j<COL;j++){
			printf("%d\t",a[i][j]);
		}
		putchar('\n');
	}
}