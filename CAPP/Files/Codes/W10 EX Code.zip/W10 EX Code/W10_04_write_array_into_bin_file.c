#include <stdio.h>

int main(){
	/*Ex 9-4: write an array into a binary file*/
	printf("Ex 9-4: write an array into a binary file\n");
	int a[20] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19};
	int i;
	// write into a file
	FILE *bin = fopen("text_9_4.sav", "wb");
	for (i=0;i<sizeof(a)/sizeof(a[0]);i++){
		fwrite(&a[i], sizeof(a[i]), 1, bin);
	}
	fclose(bin);
}