#include <stdio.h>

int main(){
	/*Ex 9-6: read a text file*/
	printf("Ex 9-6: read a text file\n");
	int a[20] = {0};
	int i;
	// read a file
	FILE *text = fopen("text_9_3.txt", "r");
	for (i=0;i<sizeof(a)/sizeof(a[0]);i++){
		fscanf(text, "%d", &a[i]);
	}
	fclose(text);
	// print array element
	for (i=0;i<sizeof(a)/sizeof(a[0]);i++){
		printf("%d\t",a[i]);
		if ((i+1)%5==0){
			putchar('\n');
		}
	}
}