#include <stdio.h>

int main(){
	/*Ex 9-1: write text file*/
	printf("Ex 9-1: write text file\n");
	int a = 0x31323334, b = 2, c = 100, d = 10;

	// write into a file
	FILE *text = fopen("text_9_1.txt", "w");
	fprintf(text, "%d %d %d %d\n", a, b, c, d);
	fclose(text);
}