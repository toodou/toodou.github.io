#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_SIZE 1024

int main(){
	/*Ex 9-9: read a csv file*/
	printf("Ex 9-9: read a csv file\n");

	// set filename
	char filename[] = "pop.csv";

	// open the file
	FILE *csv = fopen(filename, "r");

	// test whether the file can be opened
	if (!csv) {
        fprintf(stderr, "failed to open file for reading\n");
        return 1;
    }

    // read data line-by-line and set a pointer for processing data
    char line[MAX_LINE_SIZE];
    char *result = NULL;

	// move the starting pointer
	fseek(csv, 3, SEEK_SET);

	// use fgets to fetch line data in csv
	while (fgets(line, MAX_LINE_SIZE, csv) != NULL){
		// separate line data into string array by delimiter COMMA
		result = strtok(line, ",");
		// parsing data
		int i;
		for (i=0;i<9;i++){
			printf("%7d\t", atoi(result));
			result = strtok(NULL, ",");
		}
		printf("\n");
	}

	// close the file
	fclose(csv);
}