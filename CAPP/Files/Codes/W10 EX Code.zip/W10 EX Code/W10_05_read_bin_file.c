#include <stdio.h>

int main(){
	/*Ex 9-5: read a binary file*/
	printf("Ex 9-5: read a binary file\n");
	int a[20] = {0};
	int i;
	// read a file
	FILE *bin = fopen("text_9_4.sav", "rb");
	for (i=0;i<sizeof(a)/sizeof(a[0]);i++){
		fread(&a[i], sizeof(a[i]), 1, bin);
	}
	fclose(bin);
	// print array element
	for (i=0;i<sizeof(a)/sizeof(a[0]);i++){
		printf("%d\t",a[i]);
		if ((i+1)%5==0){
			putchar('\n');
		}
	}
}