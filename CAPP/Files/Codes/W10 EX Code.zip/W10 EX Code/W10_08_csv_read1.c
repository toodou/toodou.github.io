#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_SIZE 1024

int main(){
	/*Ex 9-8: read a csv file*/
	printf("Ex 9-8: read a csv file\n");

	// set filename
	char filename[] = "pop.csv";

	// open the file
	FILE *csv = fopen(filename, "r");

	// test whether the file can be opened
	if (csv==NULL) { // csv == NULL can be expressed as !csv
        fprintf(stderr, "failed to open file for reading\n");
        return 1;
    }

    // read data line-by-line
    char line[MAX_LINE_SIZE];

    // set a pointer for processing data
    char *result = NULL;

	// move the starting pointer
	fseek(csv, 3, SEEK_SET);

	// use fgets to fetch line data in csv
	fgets(line, MAX_LINE_SIZE, csv);

	// print the fetched line data
	printf("%s", line);
	printf("-----\n");

	// separate line data into string array by delimiter COMMA
	result = strtok(line, ",");

	// print line data
	printf("%s\n", line);
	printf("-----\n");

	// parsing data
	int i;
	for (i=0;i<9;i++){
		printf("%d\t", atoi(result));
		result = strtok(NULL, ",");
	}

	// close the file
	fclose(csv);
}