#include <stdio.h>

int main(){
	/*Ex 9-2: write bin file*/
	printf("Ex 9-2: write bin file\n");
	int a = 0x31323334, b = 2, c = 100, d = 10;

	// write into a file
	FILE *bin = fopen("text_9_2.sav", "wb");
	fwrite(&a, sizeof(a), 1, bin);
	fwrite(&b, sizeof(b), 1, bin);
	fwrite(&c, sizeof(c), 1, bin);
	fwrite(&d, sizeof(d), 1, bin);
	fclose(bin);
}