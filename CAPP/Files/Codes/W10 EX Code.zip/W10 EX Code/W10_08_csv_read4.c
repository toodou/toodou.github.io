#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_SIZE 1024

int main(){
	/*Ex 9-11: read a csv file*/
	printf("Ex 9-11: read a csv file\n");

	// set filename and open the file
	char filename[] = "popWithHeader.csv";
	FILE *csv = fopen(filename, "r");

	// test whether the file can be opened
	if (!csv) {
        fprintf(stderr, "failed to open file for reading\n");
        return 1;
    }

    // read data line-by-line
    // set a pointer for processing data
    // move the starting pointer
    char line[MAX_LINE_SIZE];
    char *result = NULL;
    fseek(csv, 0, SEEK_SET);
    char field[9][20];
	int date[29][2] = {0};
	char disa[29][20];
	int popa[29][6] = {0};
	int i, j, row=0;

	// use fgets to fetch line data in csv
	while (fgets(line, MAX_LINE_SIZE, csv) != NULL){
		// separate data with delimiter
		result = strtok(line, ",");
		
		// parsing data
		for (i=0; i<9; i++){
			if (row==0){
				strncpy(field[i], result, strlen(result)+1);
			}else{
				if (i<2){
					date[row-1][i] = atoi(result);
				}else if(i==2){
					//printf("%s%d\t", result, strlen(result)+1);
					strcpy(disa[row-1], result);
				}else{
					popa[row-1][i-3] = atoi(result);
				}
			}
			result = strtok(NULL, ",");
		}
		row++;
	}

	// close the file
	fclose(csv);

	// print it out for testing
	for (i=0;i<9;i++){
		if (i!=8){
			printf("%s\t", field[i]);
		}else{
			printf("%s", field[i]);
		}
	}
	for (i=0;i<29;i++){
		for (j=0;j<9;j++){
			if (j<2){
				printf("%7d\t", date[i][j]);
			}else if (j==2){
				printf("%10s\t", disa[i]);
			}else{
				printf("%7d\t", popa[i][j-3]);
			}
		}
		printf("\n");
	}
}