function myFunction3() {
    document.getElementById("demo4").innerHTML = "external JS!";
}