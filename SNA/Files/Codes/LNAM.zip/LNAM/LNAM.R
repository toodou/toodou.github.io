# load libraries
library(reshape)
library(igraph)
library(sna)
library(numDeriv)

# load data
load('~/Documents/python/social_network_analysis/studentnets.peerinfl.rda')
# how does a student (std_id) in the first semester (sem_id) like this subject (sub)?
# show the first 10 rows
head(attitudes, n=10)

# the friendship in the first semester
# show the first 10 rows
head(sem1, n=10)

# split the semester data into two parts from a long table to a wide table
attitudesw = reshape(attitudes, idvar="std_id", timevar="sem_id", direction="wide")
# show the first 10 rows
head(attitudesw, n=10)

# calculate peer influences
# create an empty array
attitudesw$mfrsub.1 = numeric(length(attitudesw$sub.1))
# calculate peer influence for each student
for(i in 1:length(attitudesw$std_id)){
  # first get alters of student i:
  altrs = sem1$alter_id[sem1$std_id == attitudesw$std_id[i]]
  # then get alters' attitudes
  altatts = attitudesw$sub.1[attitudesw$std_id %in% altrs]
  # now count how many friends like the class more than "3"
  attitudesw$nfrsubgt3[i] = length(which(altatts > 3))
  # then take the mean, ignoring NAs:
  attitudesw$mfrsub.1[i] = mean(altatts, na.rm = TRUE)}
# show the first 10 rows
head(attitudesw, n=10)

# delete all na values and obtain the average of altatts
attitudesw$mfrsub.1[i] = mean(altatts, na.rm = TRUE)
# show the first 10 rows
head(attitudesw, n=10)

# transform from a dataframe to a matrix
sem1mat <- as.matrix(sem1[1:2])

# transform from a integer to a character 
sem1mat[,1]=as.character(sem1mat[,1])
sem1mat[,2]=as.character(sem1mat[,2])

# transform edgelist to a igraph's graph
sem1graph <- igraph::graph_from_edgelist(sem1mat)
# obtain adjacent matrix
sem1matrix = igraph::get.adjacency(sem1graph)
# as a matrix
sem1matrix = as.matrix(sem1matrix)
# extract the dataframe with conditions
attitudesw = attitudesw[match(row.names(sem1matrix), attitudesw$std_id),]

# drop na values
atts = attitudesw[!is.na(attitudesw$sub.2),]
atts = atts[!is.na(atts$sub.1),]
atts = atts[!is.na(atts$mfrsub.1),]

# define a weight matrix
W = sem1matrix
# make sure the rows and columns in W are in the same order as atts:
W = W[match(atts$std_id,row.names(W)), match(atts$std_id,colnames(W))]
# make sure (this will return 0 if we did it right):
which(rownames(W) != atts$std_id)
# Linear Network Autocorrelation Model. 
pim1 <- lnam(atts$sub.2,cbind(atts$sub.1, atts$mfrsub.1), W2 = W)
# show the results
summary(pim1)

